<?php
session_start();
if(!isset($_SESSION['user_name'])){
    exit();
}
if(!isset($_SESSION)){
    header("Location:index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/tinymce/tinymce.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>
$( document ).ready(function() {
    
     $('input[name="phone"]').bind('keypress', function(e){
		var keyCode = (e.which)?e.which:event.keyCode
		return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
	});

    $('#profile').on('submit', function (e) {

        e.preventDefault();
        var form_data= $('#profile').serialize();
       
        $.ajax({
            type: 'post',
            url: 'json.php?type=profile',
            data: form_data,
            success: function (response) {
                if(response=='2'){
                
                    $('#txt').empty();
                    $('#txt').append('Some basic info is missing, all fields are required');
                    $('#myModal').modal('show');
                }
                if(response=='3'){
                    $('#txt').empty();
                    $('#txt').append('Profile info is missing, all fields are required');
                    $('#myModal').modal('show');
                }
                if(response=='1'){
                    window.location.href="success.php?from=profile";
                }
            }
      });
    });
});
</script>
<body>
<div id="main">
<?php include('navbar.php'); ?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <p style="font-weight:bold" id='txt'></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>

  </div>
</div>

<div class="clearfix"></div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        <div class="row has-sidebar">
          <div class="col-md-5 col-lg-4 col-xl-4">
              <div id="sidebar" class="sidebar-left">
                <div class="sidebar_inner">
                  <div class="list-group no-border list-unstyled">
                    
                  <?php if($_SESSION['user_type_id']!='' && $_SESSION['user_type_id']==2){ ?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                   
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item active"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_profile_pic.php" class="list-group-item"><i class="fa fa-fw fa-user"></i> My Profile picture</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                    
                 <?php }else{?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add2.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                    
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item active"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                 <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          <div class="col-md-7 col-lg-8 col-xl-8">
            <div class="page-header bordered">
              <h1>My profile <small>Manage your public profile</small></h1>
            </div>
            <form id="profile">
              <h3 class="subheadline">Basic Information</h3>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>First Name</label>
                    <input type="text" required="required" id="name" name="name" class="form-control form-control-lg" placeholder="" value="<? echo $_SESSION['user_name']?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" required="required" id="last_name" name="last_name" class="form-control form-control-lg" placeholder="" value="<? echo $_SESSION['user_surname']?>">
                  </div>
                </div>
              </div>
              
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Phone</label>
                    <input type="text" class="form-control form-control-lg" placeholder="" rerquired="required" id="phone" name="phone" value="<? echo $_SESSION['user_phone']?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Your Email</label>
                    <input type="text" required="required" id="email" name="email" readonly="readonly" class="form-control form-control-lg" value="<? echo $_SESSION['user_email']?>">
                  </div>
                </div>
              </div>
              
              <!--<h3 class="subheadline">Social Links</h3>-->
              <!--<div class="form-group">-->
              <!--  <label>Twitter</label>-->
              <!--  <div class="input-group"> <span class="input-group-addon"><i class="fa fa-fw fa-twitter"></i></span>-->
              <!--    <input type="text" class="form-control form-control-lg" placeholder="">-->
              <!--  </div>-->
              <!--</div>-->
              <!--<div class="form-group">-->
              <!--  <label>Facebook</label>-->
              <!--  <div class="input-group"> <span class="input-group-addon"><i class="fa fa-fw fa-facebook"></i></span>-->
              <!--    <input type="text" class="form-control form-control-lg" placeholder="">-->
              <!--  </div>-->
              <!--</div>-->
              <!--<div class="form-group">-->
              <!--  <label>Google Plus</label>-->
              <!--  <div class="input-group"> <span class="input-group-addon"><i class="fa fa-fw fa-google-plus"></i></span>-->
              <!--    <input type="text" class="form-control form-control-lg" placeholder="">-->
              <!--  </div>-->
              <!--</div>-->
              <!--<div class="form-group">-->
              <!--  <label>Linkedin</label>-->
              <!--  <div class="input-group"> <span class="input-group-addon"><i class="fa fa-fw fa-linkedin"></i></span>-->
              <!--    <input type="text" class="form-control form-control-lg" placeholder="">-->
              <!--  </div>-->
              <!--</div>-->
              
              <?php if($_SESSION['user_type_id']!='' && $_SESSION['user_type_id']>'0'){ 
                    $user_id = $_SESSION['user_id'];
                    require_once('MysqliDb.php');
                    $db = new MysqliDb ('rentzywp_rentzar');
                    $db->where("user_id='$user_id'");
                    $res = $db = $db->get("agents");
                    if(!empty($res)){
                        foreach($res as $key=>$value){
                            $title=$value['agent_title'];
                            $about=$value['agent_about'];
                            $address=$value['agent_address'];
                            $city=$value['agent_city'];
                        }
                    }else{
                        $title='rentzar';
                        $about='';
                        $address='';
                        $city='';
                    }
              
              ?>
              <!--<h3 class="subheadline">Agent/Landlord /Company Profile</h3>-->
              <!--<div class="form-group">-->
              <!--  <label>Agent/Company Title</label>-->
                <input type="text" hidden="hidden" required="required" id="title" name="title" value="<?php echo $title;?>" class="form-control form-control-lg">
              <!--</div>-->
              
              <div class="form-group">
               <label>About Me</label>
                    <textarea required="required" id="about" name="about" rows="6" class="form-control form-control-lg" placeholder=""><?php echo $about;?></textarea>
                </div>  
              <div class="row">
                <div class="col-lg-6">
                  <div class="form-group">
                   <label>Address</label>
                    <input type="text" required="required" id="address" name="address" value="<?php echo $address;?>" class="form-control form-control-lg" placeholder="">
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-group">
                     <label>City</label>
                    <input type="text" value="<?php echo $city;?>" required="required" id="city" name="city" class="form-control form-control-lg" placeholder="" id="locality">
                  </div>
                </div>
                
              </div>
              <hr>
              <?php } ?>
              <div class="form-group action">
                <button type="submit" class="btn btn-lg btn-primary">Update Profile</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<script>
var placeSearch, autocomplete;
var componentForm = {
	//street_number: 'short_name',
	//route: 'long_name',
	locality: 'long_name',
	administrative_area_level_1: 'long_name',
	country: 'long_name',
	postal_code: 'long_name'
};

function initAutocomplete() {
	autocomplete = new google.maps.places.Autocomplete((document.getElementById('autocomplete')), {types: ['geocode']});
	autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
	var place = autocomplete.getPlace();
	for (var component in componentForm) {
		document.getElementById(component).value = '';
		document.getElementById(component).disabled = false;
	}
	
	for (var i = 0; i < place.address_components.length; i++) {
		var addressType = place.address_components[i].types[0];
		if (componentForm[addressType]) {
			var val = place.address_components[i][componentForm[addressType]];
			document.getElementById(addressType).value = val;
		}
	}
}
</script> 
<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete" async defer></script> 
<script>
	tinymce.init({
		selector: '.text-editor',
		height: 200,
		menubar: false,
		branding: false,
		plugins: [
			'lists link image preview',
		],
		toolbar: 'undo redo | link | formatselect | bold italic underline  | alignleft aligncenter alignright alignjustify | bullist numlist'
	});
        </script>
</body>
</html>