<?php 
session_start();
if(!isset($_SESSION['user_name'])){
    exit();
}
if(!isset($_SESSION)){
    header("Location:index.php");
    exit();
}


// echo '<pre>';
// print_r($_SESSION);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/tinymce/tinymce.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>
$( document ).ready(function() {
    
     $('input[name="phone"]').bind('keypress', function(e){
		var keyCode = (e.which)?e.which:event.keyCode
		return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
	});

    $('#inline_pass').on('submit', function (e) {

        e.preventDefault();
        var form_data= $('#inline_pass').serialize();
       
        $.ajax({
            type: 'post',
            url: 'json.php?type=inline_reset',
            data: form_data,
            success: function (response) {
                
                if(response=='2'){
                    $('#txt').empty();
                    $('#txt').append('Passwords do not match');
                    $('#myModal').modal('show');
                }
                if(response=='3'){
                    $('#txt').empty();
                    $('#txt').append('All fields are required');
                    $('#myModal').modal('show');  
                }
                
                if(response=='4'){
                   $('#txt').empty();
                    $('#txt').append('Invalid details provided');
                    $('#myModal').modal('show');
                }
                if(response=='1'){
                    window.location.href="success.php?from=inline_change";
                }
            }
      });
    });
});
</script>
<body>
    <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <p style="font-weight:bold" id='txt'></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
      </div>
    </div>

  </div>
</div>
<div id="main">
<?php include('navbar.php'); ?>
<div class="clearfix"></div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        <div class="row has-sidebar">
          <div class="col-md-5 col-lg-4 col-xl-4">
            <div id="sidebar" class="sidebar-left">
              <div class="sidebar_inner">
                <div class="list-group no-border list-unstyled">
                    
                   <?php if($_SESSION['user_type_id']!='' && $_SESSION['user_type_id']==2){ ?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                   
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_profile_pic.php" class="list-group-item"><i class="fa fa-fw fa-user"></i> My Profile picture</a>
                    <a href="my_password.php" class="list-group-item active"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                    
                 <?php }else{?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add2.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                    
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_password.php" class="list-group-item active"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                 <?php } ?>
                   
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-7 col-lg-8 col-xl-8">
            <div class="page-header bordered">
              <h1>Change Password</h1>
             <?php  
                if(isset($_SESSION['user_fb'])){
                    echo '<p style="color:#ea621e">You cannot use this function to change your password if you are logged in with Facebook</p>'; 
                    
                    exit();
                    
                } 
            ?>
            </div>
            <form id="inline_pass">
              <div class="form-group">
                <label>Your current password</label>
                <input type="password" class="form-control form-control-lg" placeholder="Your current password" required="required" id="current_password" name="current_password" autofocus>
              </div>
              <div class="form-group">
                <label>Your new password</label>
                <input type="password" class="form-control form-control-lg" placeholder="Your new password" required="required" id="new_password" name="new_password">
              </div>
              <div class="form-group">
                <label>Repeat new password</label>
                <input type="password" required="required" id="new_password_con" name="new_password_con" class="form-control form-control-lg" placeholder="Repeat new password">
              </div>
              <hr>
              <div class="form-group action">
                <button type="submit" class="btn btn-lg btn-primary">Update Password</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div> 
</body>
</html>