<?php 
session_start();
if(!isset($_SESSION['user_name'])){
    exit();
}
$stat_agent = '';
if(isset($_SESSION['user_id'])){
    $id__=$_SESSION['user_id'];
    require_once('MysqliDb.php');
    $db22 = new MysqliDb ('rentzywp_rentzar');
    $db22->where("user_id='$id__'");
    $result22=$db22->get('agents');
    if(empty($result22)){
        $stat_agent=0;
    }else{
        $stat_agent='1';
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/tinymce/tinymce.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>

function deposit_text(){
    var status_ = $('#deposit_select').val();
    if(status_ == '0'){
        $('.deposit_price').hide();
         $('#deposit_price').val('');
        
    }
    if(status_ == '1'){
        $('.deposit_price').show();
    }
}
$(function()
{
    
    $('.deposit_price').hide();
    
//     $(document).on('click', '.btn-add', function(e)
//     {
//         e.preventDefault();

//         var controlForm = $('.controls:first'),
//             currentEntry = $(this).parents('.entry:first'),
//             newEntry = $(currentEntry.clone()).appendTo(controlForm);

//         newEntry.find('input').val('');
//         controlForm.find('.entry:not(:last) .btn-add')
//             .removeClass('btn-add').addClass('btn-remove')
//             .removeClass('btn-success').addClass('btn-danger')
//             .html('<span class="fa fa-minus"></span>');
//     }).on('click', '.btn-remove', function(e)
//     {
//       $(this).parents('.entry:first').remove();

//     e.preventDefault();
//     return false;
//   });
});


</script>

<body>
<div id="main">
<?php include('navbar.php'); ?>
<div class="clearfix"></div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        <div class="row has-sidebar">
          <div class="col-md-5 col-lg-4 col-xl-4">
            <div id="sidebar" class="sidebar-left">
              <div class="sidebar_inner">
                <div class="list-group no-border list-unstyled">
                    
                 <?php if($_SESSION['user_type_id']!='' && $_SESSION['user_type_id']==2){ ?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add.php" class="list-group-item active"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                   
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_profile_pic.php" class="list-group-item"><i class="fa fa-fw fa-user"></i> My Profile picture</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                    
                 <?php }else{?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add2.php" class="list-group-item active"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                    
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item "><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                 <?php } ?>
                   
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-7 col-lg-8 col-xl-8">
            <div class="page-header bordered">
              <h1>Submit your dream accomodation</h1>
              <?php 
              
              if($stat_agent!='1'){
                  
                  echo '<br><h1 style="color:#ea621e"><small style="color:#ea621e">Please update your profile details before continuing here</small></h1>';
                  exit();
              }
              ?>
            </div>
            <form id="add_list" action="added_item2.php" method="post" enctype="multipart/form-data">
              <center><h3 class="subheadline">Basic Details</h3></center>
              <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control form-control-lg" id="title" name="title" required="required" placeholder=" Title" autofocus>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Price</label>
                    <input type="text" id="price" name="price" required="required" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="form-control form-control-lg" placeholder="Price">
                  </div>
                 </div>
                 <div class="col-sm-6">
                  <div class="form-group">
                    <label for="property_type">Preffered accomodation</label>
                    <select  required="required" name="property_type" id="property_type" class="form-control form-control-lg ui-select">
                        <option select="selected" value="">--select--</option>
                        <?php
                            require_once('MysqliDb.php');
                            $db11 = new MysqliDb ('rentzywp_rentzar');
                            $result1=$db11->get('property_type');
                            if(!empty($result1)){
                              foreach ($result1 as $key1 => $value1) {
                                echo '<option value="'.$value1["type_id"].'">'.$value1["type_description"].'</option>';
                              }
                            }
                            ?> 
                    </select>
                  </div>
                 </div>
                </div>
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="bedrooms">Bedrooms</label>
                    <select required="required" name="bedrooms" id="bedrooms" class="form-control form-control-lg ui-select">
                      <option value="0">0</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7+">7+</option>
                    </select>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="bathrooms">Bathrooms</label>
                    <select required="required" name="bathrooms" id="bathrooms" class="form-control form-control-lg ui-select">
                      <option value="1">1+</option>
                      <option value="2">2+</option>
                      <option value="3">3+</option>
                      <option value="4">4+</option>
                      <option value="5">5+</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="deposit">Deposit available ?</label>
                    <select onchange="deposit_text()" required="required" name="deposit" id="deposit_select" class="form-control form-control-lg ui-select">
                      <option value="0" selected="selected">No</option>
                      <option value="1">Yes</option>
                    </select>
                  </div>
                </div>
                <div class=" deposit_price col-sm-6">
                  <div class="form-group">
                    <label for="deposit_price" class="deposit_price">Deposit %?</label>
                     <select  required="required" name="deposit_price" id="deposit_price" class="deposit_price form-control form-control-lg ui-select">
                      <option value="0" selected="selected">None</option>
                      <option value="10%">10%</option>
                      
                      <option value="20%">20%</option>
                      
                      <option value="30%">30%</option>
                      <option value="40%">40%</option>
                      
                      
                          
                      <option value="50%">50%</option>
                      
                      <option value="60%">60%</option>
                      
                      <option value="70%">70%</option>
                      
                      <option value="80%">80%</option>
                      
                      <option value="90%">90%</option>
                      
                      <option value="100%">100%</option>
                    </select>
                  </div>
                </div>
             </div>
             <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="rent">Rental type</label>
                    <select required="required" name="rent" id="rent" class="form-control form-control-lg ui-select">
                        <option value="any" selected="selected">Any</option>
                      <option value="monthly">Monthly</option>
                      <option value="weekly">Weekly</option>
                    </select>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="parking">Parking required?</label>
                    <select required="required" name="parking" id="parking" class="form-control form-control-lg ui-select">
                      <option value="0" selected="selected">No parking required</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4+</option>
                    </select>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="indi_share">Property for</label>
                     <select  required="required" name="indi_share" id="indi_share" class="form-control form-control-lg ui-select">
                      <option value="Any" selected="selected">Any</option>
                      <option value="Sharing">Sharing</option>
                      <option value="Individual">Individual</option>
                    </select>
                  </div>
                </div>
                
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="period">Lease period</label>
                    <select   name="period" id="period" class="form-control form-control-lg ui-select">
                        <option value="any" selected="selected">Any</option>
                      <option value="6 months">6 months</option>
                      <option value="12 months">12 months</option>
                      <option value="24 months">24 months</option>
                      <option value="48 months">48 months</option>
                    </select>
                  </div>
                </div>
             <div> 
             
             
<center><h3 class="subheadline">Location</h3></center>
  <div class="row">
    <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>Location / address</label>
            <textarea required="required" class="form-control form-control-lg" id="autocomplete" name="location" placeholder="Enter your city, street,province here">
            </textarea>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>City</label>
            <input type="text" required="required" readonly="readonly" class="form-control form-control-lg" placeholder="" id="locality" name="city">
          </div>
        </div>
      </div>
    </div>

     <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>Province</label>
            <input type="text" required="required" readonly="readonly" class="form-control form-control-lg" placeholder="" id="administrative_area_level_1" name="province">
          </div>
        </div>
      </div>
    </div>
  </div> 
  <div class="row">
    <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>Country</label>
           <input type="text" required="required" readonly="readonly" class="form-control form-control-lg" placeholder="" id="country" name="country">
          </div>
        </div>
      </div>
    </div>

     <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>Zipcode</label>
           <input type="text" class="form-control form-control-lg" placeholder="" readonly="readonly" name="postal" id="postal_code">
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>Other location / address</label>
            <textarea  class="form-control form-control-lg" id="other_address" name="other_address" placeholder="Other location / address"></textarea>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-6">
      <div class="form-group">
        <div class="col-lg-12">
          <div class="form-group">
            <label>Accomodation Description</label>
            <textarea class="form-control form-control-lg" id="Description" name="Description" placeholder="" required="required"></textarea>
          </div>
        </div>
      </div>
    </div>
  </div>  

              
              
               
              <hr>
            <center>
            <div class="row">
                <div class="col-sm-6">  
                    <div class="form-group">
                    <button type="submit" class="btn btn-lg btn-primary">Submit</button>
                    </div>
                </div>
            </div>
            </center> 
              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<script>

var placeSearch, autocomplete;
var componentForm = {
  //street_number: 'short_name',
  //route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'long_name',
  country: 'long_name',
  postal_code: 'long_name'
};

function initAutocomplete() {
  autocomplete = new google.maps.places.Autocomplete((document.getElementById('autocomplete')), {types: ['geocode']});
  autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
  var place = autocomplete.getPlace();
  for (var component in componentForm) {
    document.getElementById(component).value = '';
    document.getElementById(component).disabled = false;
  }
  
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      document.getElementById(addressType).value = val;
    }
  }
}
</script> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBvuspZieDAMlpAVAe2qwlvkk8oQU34dtg&libraries=places&callback=initAutocomplete" async defer></script> 
<script>
  tinymce.init({
    selector: '.text-editor',
    height: 200,
    menubar: false,
    branding: false,
    plugins: [
      'lists link image preview',
    ],
    toolbar: 'undo redo | link | formatselect | bold italic underline  | alignleft aligncenter alignright alignjustify | bullist numlist'
  });
        </script>
</body>
</html>