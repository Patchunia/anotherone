<?php
if(isset($_REQUEST['hash'])){
    $hash=$_REQUEST['hash'];
    require_once('MysqliDb.php');
    $db = new MysqliDb ('rentzywp_rentzar');
    $db->where("user_password='$hash'");
    $db->where("account_status='0'");
    $result = $db->get('users');
    if(!empty($result)){
        
        foreach($result as $key=>$value){
            $date = $value['create_date'];
        }
        
        $current_time = date('Y-m-d H:i:s');
        $current_time = strtotime($current_time);
		$initial_request_time = strtotime($date);
		$difference_in_minutes = round(abs($current_time - $initial_request_time) / 60,2);

		if($difference_in_minutes >= 60){
		    echo '<div>This link has expired! </div>&nbsp;';
            echo '<br>';
            echo '<div>Visit <a style="color:#ea621e" href="www.lets-snap.co.za/rentzar_rentzar_rentzar222">RentZAr</a> to create a new account or sign in</div>';
        
            $db3 = new MysqliDb ('rentzywp_rentzar');
            $db3->where("user_password='$hash'");
            $db3->where("account_status='0'");
            $db3->delete('users');
            exit();
		}else{
		    $data2['account_status']='1';
            $db2 = new MysqliDb ('rentzywp_rentzar');
            $db2->where("user_password='$hash'");
            $db2->update('users',$data2);
		}
        
        
        
    }else{
        echo '<p><b>Your account is already active or does not exist</b></p>';
            
        echo '<p></b>Click <a href="signin.php" style="color:#ea621e">here </a> to login.</b>';
        exit();
    }
}else{
    echo '<p><b>Your account is already active or does not exist</b></p>';
            
        echo '<p></b>Click <a href="signin.php" style="color:#ea621e">here </a> to login.</b>';
        exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<div id="main">
    <br><br>
<div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-md-8  col-lg-6">
         
        <div class="page-header">
        <h1 style="color:#ea621e">Account confirmation</h1>
        </div>
      </div>
    </div>
  </div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
        
      <div class="col col-md-8  col-lg-6">
      <p><b>Your account is successfully confirmed</b></p>
            
        <p></b>Click <a href="signin.php" style="color:#ea621e">here </a> to login.</b>
        
        <div> </div>
      </div>
    </div>
  </div>
</div>
</div>

</body></html>