<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="main">
<?php if(isset($_REQUEST['from'])){
 if($_REQUEST['from']!='reset'){
    include('navbar.php');
 }
}
?>
<?php 
            if(isset($_REQUEST['from'])){
                if($_REQUEST['from']=='suggestion'){
                    $msg='your suggestion was not sent';
                    $link='suggestion.php';
                }
                if($_REQUEST['from']=='contact'){
                    $msg='your message was not sent';
                    $link='contact.php';
                }
                if($_REQUEST['from']=='signin'){
                    $msg='invalid sign in details';
                    $link='signin.php';
                }
                if($_REQUEST['from']=='forgot'){
                    $msg='We do not know this email';
                    $link='forgot-password.php';
                }
                if($_REQUEST['from']=='reset'){
                    $msg='invalid details';
                    $link='#';
                }
                if($_REQUEST['from']=='register'){
                    $msg='Registration unsuccessful';
                    $link='register.php';
                }
                 if($_REQUEST['from']=='inline_change'){
                    $msg='Password update unsuccessful';
                    $link='my_password.php';
                }
                if($_REQUEST['from']=='add_listing'){
                    if($_REQUEST['error_list']=='1'){
                        $msg='Property listing was successful but some images where not uploaded';
                        $link='my_listing_add.php';
                    }
                    
                }
                
                if($_REQUEST['from']=='my_propic'){
                    if($_REQUEST['error_list']=='1'){
                        $msg='Profile photo was not successful uploaded';
                        $link='my_profile_pic.php';
                    }
                    
                }
                
                if($_REQUEST['from']=='chat_agent'){
                    $id =$_REQUEST['id'];
                        $msg='You contact message was not sent';
                        $link='property_single.php?id='.$id.'';
                    
                    
                }
                
                if($_REQUEST['from']=='contact_agent'){
                    $id =$_REQUEST['id'];
                        $msg='You contact message was not sent';
                        $link='agent.php?id='.$id.'';
                    
                    
                }
                
                
            }else{
                $msg='an error has occured, Requested page not found!';
                $link='index.php';
            }
        ?>
        
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-lg-8">
        <div class="error-template text-center"> <i class="fa fa-exclamation-triangle fa-5x text-danger animated zoomIn mb50"></i>
          <h3 class="main-title"><span>Oops!</span></h3>
          <div class="main-title-description"> Sorry, <?php echo $msg; ?></div>
          <div class="error-actions"> <a href="<?php echo $link; ?>" class="btn btn-primary btn-lg">Try again </a> <a href="contact.php" class="btn btn-light btn-lg">Contact Support </a> </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php if(isset($_REQUEST['from'])){
 if($_REQUEST['from']!='reset'){
    include('footer.php');
 }
}
?>
</div>

</body></html>