<?php
require_once('MysqliDb.php');
if(isset($_REQUEST['prop_id'])){
    $prop_id = $_REQUEST['prop_id'];
    $db2 = new MysqliDb ('rentzywp_rentzar');
    $db2->where("prop_id='$prop_id'");
    $res=$db2->get('property',$data2);
    
    if(!empty($res)){
        foreach($res as $key => $value){
            $loc = $value['prop_loc'];
        }
    }else{
        exit();
    }
}else{
    exit();
}

 
?>
<!DOCTYPE html>
<html>
  <head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
 
   
  </head>
   <style>
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #pano {
        height: 450px;
        width: 600px;
      }
    </style>
  <body onload="initMap();">
     
    <div id="pano"></div>
    <script>
    var latt='';
    var lonn='';
    var map;
      function initialize() {
          
          var geocoder = new google.maps.Geocoder();
        var address = '<?php echo $loc;?>';
        
        geocoder.geocode( { 'address': address}, function(results, status) {
        
          if (status == google.maps.GeocoderStatus.OK) {
              latt = results[0].geometry.location.lat();
             lonn = results[0].geometry.location.lng();
             
             alert(latt);
          } 
        }); 
        
        var fenway = {lat:parseFloat(latt), lng: parseFloat(lonn)};
         
        var panorama = new google.maps.StreetViewPanorama(
            document.getElementById('pano'), {
              position: fenway,
              pov: {
                heading: 34,
                pitch: 10
              }
            });
        map.setStreetView(panorama);
      }
    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_7fsPdy-DqoPWNZ-0A6Z90IqaZvfhTDs&callback=initialize">
    </script>
  </body>
</html>