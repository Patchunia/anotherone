<?php
session_start();
if(isset($_REQUEST['id'])){
    $agent_id=$_REQUEST['id'];
   
}else{
    exit();
}

require_once('MysqliDb.php');
$db1 = new MysqliDb ('rentzywp_rentzar');
$db1->where("user_id='$agent_id'");
$result=$db1->get('agents');

if(!empty($result)){
  foreach ($result as $key => $value) {
    $about    =$value['agent_about'];
    $address         =$value['agent_address'];
    $city         =$value['agent_city'];
    $profile_pic           =$value['agent_profile_pic'];
    $user_id =$value['user_id'];
    $cur_pic = $value['agent_profile_pic'];
  }
}

$db11 = new MysqliDb ('rentzywp_rentzar');
$db11->where("user_id='$user_id'");
$result1=$db11->get('users');
if(!empty($result1)){
  foreach ($result1 as $key1 => $value1) {
    $agent_name    =$value1['user_name'];
    $agent_sname  =$value1['user_surname'];
    $agent_phone     =$value1['user_phone'];
    $agent_email =$value1['user_email'];
    $user_type_id = $value1['user_type_id'];
  }
}

 

if($cur_pic==''){
    $cur_pic='dummy.jpg';
    $src ="agents/Global_profile_pic/$cur_pic"; 
}else{
    $src ="agents/$user_id/profile/$cur_pic"; 
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<style>
   
    .item-title>a{
        color:#ea621e !important;
    }
    .added-by{
        color:black !important;
    }
</style>
<script>
function sub(){

    $('#the_sub').click();
}
$( document ).ready(function() {
    
    $('input[name="lead_phone"]').bind('keypress', function(e){
    var keyCode = (e.which)?e.which:event.keyCode
    return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
  });
  
    $('#agent_form').on('submit', function (e) {

        e.preventDefault();
        var form_data= $('#agent_form').serialize();
    
        $.ajax({
            type: 'post',
            url: 'json.php?type=contact_agent',
            data: form_data,
            success: function (response) {
                if(response=='1'){
                    window.location.href="success.php?from=contact_agent&id=<?php echo $agent_id;?>";
                }else{
                     window.location.href="404_error.php?from=contact_agent&id=<?php echo $agent_id;?>"
                }
                //window.location.reload();
            }
      });
    });
});
</script>
<body>
    <?php
if(isset($_SESSION['user_id'])){
  $name=$_SESSION['user_name'];
  $email=$_SESSION['user_email'];
}else{
  $name='';
  $email='';
}
?>
<div id="main">
<?php include('navbar.php'); ?>
<div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
 
        </div>
        </div>
        </div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        <div class="row has-sidebar">
          <div class="col-md-5 col-lg-4 col-xl-4">
            <div id="sidebar" class="sidebar-left">
              <div class="sidebar_inner">
              <div class="agent-details"> 
              
               
                
              <img class="img-fluid img-rounded agent-thumb" src="<?php echo $src; ?>" alt="">
               
                <h3 class="subheadline"><?php echo $agent_name.' '.$agent_sname;?></h3>
                <!--<ul class="list-unstyled">-->
                <!--  <li><a href="tel:<?php// echo $agent_phone; ?>"><i class="fa fa-phone fa-fw" aria-hidden="true"></i> Call: <?php echo $agent_phone;?></a></li>-->
                <!--  <li><a href="#"><i class="fa fa-globe fa-fw" aria-hidden="true"></i> <?php// echo $agent_email;?></a></li>-->
                <!--</ul>-->
                <a href="#" class="btn btn-lg btn-primary btn-block" data-toggle="modal" data-target="#leadform">Contact <?php echo $agent_name;?></a> </div>
                </div>
            </div>
          </div>
          <div class="col-md-7 col-lg-8 col-xl-8">
            <div class="page-header mt-0">
            <h1 style="color:#ea621e">About <?php echo $agent_name.' '.$agent_sname;?> <small><i class="fa fa-map-marker"></i> <?php echo $address.' '.$city;?></small></h1>
            </div>
            <p><?php echo $about; ?></p>
            <hr/>
            <div class="lead">Recent properties by <?php echo $agent_name.' '.$agent_sname;?></div>
         
            <div class="clearfix"></div>
            <div class="item-listing list">
                <?php 
                $db11 = new MysqliDb ('rentzywp_rentzar');
                $db11->where("user_id='$user_id'");
                $result1=$db11->get('property');
                if(!empty($result1)){
                  foreach ($result1 as $key1 => $value1) {
                    $image_name    =$value1['prop_main'];
                    $price         =$value1['prop_price'];
                    $title         =$value1['prop_title'];
                    $loc           =$value1['prop_loc'];
                    $bed           =$value1['prop_bed'];
                    $bath          =$value1['prop_bath'];
                    $prop_id       =$value1['prop_id'];
                    $date          =$value1['date'];
                    
                    if($user_type_id=='2'){
                     $src2 = 'agents/'.$user_id.'/property/'.$prop_id.'/main/'.$image_name;
                    }else{
                        $src2 = 'agents/stock_image.png';
                    }
                ?>
                
                <div class="item">
                <div class="row">
                  <div class="col-lg-5">
                     
                    
                    <div class="item-image"> <a href="property_single.php?id=<?php echo $prop_id;?>"><img src="<?php echo $src2; ?>" class="img-fluid" alt="">
                      
                      <div class="item-meta">
                      <div class="item-price"><?php echo 'R'.$price; ?>
                      </div>
                      </div>
                      </a>
                      <!-- <a href="#" class="save-item"><i class="fa fa-star"></i></a> --> </div>
                  </div>
                  <div class="col-lg-7">
                  <div class="item-info">
                    <h3 class="item-title" style="color:#ea621e"><a href="property_single.php?id=<?php echo $prop_id;?>"><?php echo $title;?></a></h3>
                    <div class="item-location"><i class="fa fa-map-marker"></i> <?php echo $loc;?></div>
                    <div class="item-details-i"> <span class="bedrooms" data-toggle="tooltip" title="<?php echo $bed;?> Bedrooms"><?php echo $bed;?> <i class="fa fa-bed"></i></span> <span class="bathrooms" data-toggle="tooltip" title="<?php echo $bath;?> Bathrooms"><?php echo $bath;?> <i class="fa fa-bath"></i></span> </div>
                     <br>
                 </div>
                    <div class="row">
                    <div class="col-md-6">
                                        <div class="added-on">Listed on <?php echo $date;?> </div>

                    </div>
                    <div class="col-md-6">
                                         <a href="#" class="added-by">by <?php echo $agent_name;?></a>

                    </div>
                    </div>
                  </div>
                </div>
              </div>
                
                <?php
                    
                  }
                }
                ?>
                
                
              
              
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Contact Agent Modal -->
<div class="modal fade  item-badge-rightm" id="leadform" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div class="media"> 
          <div class="media-left"><img src="<?php echo $src; ?>" class="img-rounded" width="64" alt=""> </div>
          <div class="media-body">
            <h4 class="media-heading" id="leadformLabel">Send Message to <?php echo ucfirst($agent_name); ?></h4>
            <ul class="list-unstyled">
              <!--<li><a href="tel:<?php// echo $agent_phone; ?>"><i class="fa fa-phone fa-fw" aria-hidden="true"></i> Call: <?php// echo $agent_phone; ?></a></li>-->
              <!--<li><a href="#"><i class="fa fa-globe fa-fw" aria-hidden="true"></i> <?php// echo $agent_email; ?></a></li>-->
               
              
            </ul>
          </div>
        </div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="agent_form" >
            <input hidden="hidden" type="text" id="agent_mail" name="agent_mail" value="<?php echo $agent_email; ?>"> 
          <div class="form-group">
            <label for="name">Your Name</label>
            <input required="required" type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" placeholder="Your Name">
          </div>
          <div class="form-group">
            <label for="email">Your Email</label>
            <input required="required" value="<?php echo $email; ?>"  type="email" class="form-control" id="email" name="email" placeholder="Your Email">
          </div>
          <div class="form-group">
            <label for="lead_phone">Your Telephone</label>
            <input required="required"  type="tel" class="form-control" id="lead_phone" maxlength="10" name="lead_phone" placeholder="Your Telephone">
          </div>
          <div class="form-group">
            <label for="lead_requirement">Type of enquiry</label>
            <select required="required"  class="form-control ui-select" id="lead_requirement" name="lead_requirement">
              <option value="" disabled="disabled" selected="selected">Please select:</option>
              <option value="I am looking to rent a property">I am looking to rent a property</option>
              <option value="I want a valuation of my property">I want a valuation of my property</option>
              <option value="I have a property to let">I have a property to let</option>
            </select>
          </div>
          <div class="form-group">
            <label for="lead_message">Message</label>
            <textarea required="required" name="lead_message" id="lead_message" rows="4" class="form-control" placeholder="Please include any useful details, i.e. current status, availability for viewings, etc."></textarea>
          </div>
          <button type="submit" hidden="hidden" id="the_sub"></button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="can" class="btn btn-link" data-dismiss="modal">Cancel</button>
        <button type="button"  onclick="sub()" class="btn btn-primary">Send Message</button>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>

</body></html>