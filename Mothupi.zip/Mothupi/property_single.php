<?php
session_start();
if(!isset($_REQUEST['id'])){
exit();
}else{
$prop_id= $_REQUEST['id'];
} 
if(isset($_SESSION['user_id'])){
$name=$_SESSION['user_name'];
$email=$_SESSION['user_email'];
}else{
$name='';
$email='';
} 
require_once('MysqliDb.php');
$db1 = new MysqliDb ('rent');
$db1->where("prop_id='$prop_id'");
$result=$db1->get('property');
if(!empty($result)){
foreach ($result as $key => $value) {
$image_name    =$value['prop_main'];
$price         =$value['prop_price'];
$title         =$value['prop_title'];
$loc           =$value['prop_loc'];
$bed           =$value['prop_bed'];
$bath          =$value['prop_bath'];
$user_id       =$value['user_id'];
$prop_desc     =$value['prop_desc'];
$indi_share    =$value['prop_ind_share'];


$prop_deposit              =$value['prop_deposit'];
$prop_rental_type          =$value['prop_rental_type'];
$prop_preffered_tenant     =$value['prop_preffered_tenant'];
$prop_water_include        =$value['prop_water_include'];
$prop_elec_include         =$value['prop_elec_include'];
$prop_lease_period         =$value['prop_lease_period'];
$prop_view_times           =$value['prop_view_times'];
$prop_area                 =$value['prop_area'];

$parking = $value['prop_parking'];

$from_day=$value['from_day'];
$to_day=$value['to_day'];
$from_time=$value['from_time'];
$to_time=$value['to_time'];

if($prop_water_include==1){
$prop_water_include='included';
}else{
$prop_water_include='excluded';
}

if($prop_elec_include==1){
$prop_elec_include='included';
}else{
$prop_elec_include='excluded';
}
$prop_features =$value['prop_features'];
$prop_features = explode(',',$prop_features);
$prop_features = array_filter($prop_features);
$prop_other =$value['prop_other'];
$prop_other = explode(',',$prop_other);
$prop_other = array_filter($prop_other);
foreach($prop_other as $key7=> $value7){
$ander[] = $value7;
}

$main_image_path = 'agents/'.$user_id.'/property/'.$prop_id.'/main/'.$image_name;

if (!file_exists($main_image_path)) {
$main_image_path = 'agents/stock_image.png';
}

if($user_type_id=='1'){
$main_image_path = 'agents/stock_image.png';
}

$db2 = new MysqliDb ('rent');
$db2->where("user_id='$user_id'");
$result2=$db2->get('users');
foreach($result2 as $key2 => $value2){
$agent_name = $value2['user_name'];
$agent_tel = $value2['user_phone'];
$agent_email = $value2['user_email'];
$user_type_id = $value2['user_type_id'];
}
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/swiper/css/swiper.min.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link rel="stylesheet" href="lib/photoswipe/photoswipe.css"> 
<link rel="stylesheet" href="lib/photoswipe/default-skin/default-skin.css"> 
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<!--<script src="lib/swiper/js/swiper.min.js"></script>-->
<script src="lib/aos/aos.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/photoswipe/photoswipe.min.js"></script>
<script src="lib/photoswipe/photoswipe-ui-default.min.js"></script>
<script src="lib/lib.js"></script>



<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<style>
    .modal-content{
        min-width:100%;
    }
    
/*    .zoom {*/
    
/*    transition: transform .2s; */

/*    margin: 0 auto;*/
/*}*/

/*.zoom:hover {*/
/*    transform: scale(1.3); */
/*}*/
</style>
<script>

$(function() {
		$('.pop').on('click', function() {
			$('.imagepreview').attr('src', $(this).find('img').attr('src'));
			$('#imagemodal').modal('show');   
		});		
});

function zoom_(id){
     
}

      function sub(){

    $('#the_sub').click();
}
$( document ).ready(function() {
     
     $('input[name="phone"]').bind('keypress', function(e){
var keyCode = (e.which)?e.which:event.keyCode
return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$('#chat_agent').on('submit', function (e) {

e.preventDefault();
var form_data= $('#chat_agent').serialize();
$.ajax({
type: 'post',
url: 'json.php?type=chat_agent',
data: form_data,
success: function (response) {
if(response=='1'){
window.location.href="success.php?from=chat_agent&id=<?php echo $prop_id;?>";
}else{
window.location.href="404_error.php?from=chat_agent&id=<?php echo $prop_id;?>";
}
}
});
});
    
});
</script>
<body>
<div id="main">
<?php include('navbar.php'); ?>

<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body zoom">
      	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <img src="" class="imagepreview" style="width: 100%;" >
      </div>
    </div>
  </div>
</div>

<div class="container">
  <div class="row justify-content-md-center">
          <div class="col col-md-12 col-lg-12 col-xl-10">
    
      <div class="page-header bordered mb0">
    
            <div class="row">
              <div class="col-md-8"> <a href="#" onclick="window.history.back()" class="btn-return" title="Back"><i class="fa fa-angle-left"></i></a>
                <h1><?php echo $title; ?> <small><i class="fa fa-map-marker"></i> <?php echo $loc;?></small></h1>
              </div>
              <div class="col-md-4">
                <div class="price"><?php echo 'R '.$price;?></div>
              </div>
            </div>
            
      </div>
    </div>
  </div>
</div>
<div id="content" class="item-single">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-md-12 col-lg-12 col-xl-10">
        <div class="row row justify-content-md-center has-sidebar">
          <div class="col-md-7 col-lg-8">
            <div>
              <div class="item-gallery">
                <div class="swiper-container gallery-top" data-pswp-uid="1">
                  <div class="swiper-wrapper">
                  
                    <div class="swiper-slide">
                    <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject"> <a href="<?php echo $main_image_path; ?>"  itemprop="contentUrl" data-size="2000x1414" class="pop"> <img src="<?php echo $main_image_path; ?>" class="img-fluid swiper-lazy" alt=""> </a> </figure>
                    </div>
                    
                  </div>
                  <!--<div class="swiper-button-next"></div>-->
                  <!--<div class="swiper-button-prev"></div>-->
                </div>
                <div class="swiper-container gallery-thumbs">
                  <div class="swiper-wrapper">
                    <?php
                    
                    if($user_type_id=='2'){
                        foreach($ander as $key => $value){ 
                          $other_image_path = 'agents/'.$user_id.'/property/'.$prop_id.'/thumbs/'.$value;
                          
                            if (!file_exists($other_image_path)) {
                              $other_image_path = 'agents/stock_image.png';
                            }
                    
                    ?>
                    <div class="swiper-slide">
                        <div class="pop">
                            <img   src="<?php echo $other_image_path; ?>" class="img-fluid" alt="">
                        </div>
                    </div>
                     <?php }
                     }  
                     ?>
                    
                    
                  </div>
                  
                </div>
              </div>
              <div>
                <ul class="item-features">
                  <li><span class="fa fa-bed"><?php echo ' '.$bed;?></span> </li>
                  <li><span class="fa fa-bath"><?php echo ' '.$bath;?></span></li>
                  <?php if($user_type_id=='2'){ ?>
                  <li><?php echo 'R'.$prop_deposit.' deposit'; ?></li>
                  <?php }else{ ?> 
                  <li><?php echo $prop_deposit.' deposit'; ?></li>
                  <?php } ?>
                </ul>
                
                <div class="item-description">
                    
                  <p></p><?php// echo $prop_rental_type.' rental';?></p>
                  <?php// if ($user_type_id=='2'){ ?>
                  <p><?php echo 'Water '.$prop_water_include; ?></p>
                  <p><?php echo 'Electricity '.$prop_elec_include;?></p>
                  <?php// }?>
                  <p><?php echo $prop_lease_period.' lease period'; ?></p>
                  
                  <?php// if($user_type_id=='1'){ ?>
                  <p><?php echo 'Parking ('.$parking.')';?></p>
                  <?php// } ?>
                  
                  <?php if($user_type_id=='2'){ ?>
                  <p style="font-weight:bold">Viewing times</p>
                  <p>From <?php echo $from_day.' to '.$to_day; ?></p>
                  <p><?php echo $from_time.' to '.$to_time; ?></p>
                  <?php } ?>
                </div>
                
                
                <div class="item-description">
                  <h3 class="headline">Accomodation description</h3>
                  <p><?php echo $prop_desc; ?></p>
                  
                </div>
                
                <?php if($user_type_id=='2'){ ?>
                <div class="item-description">
                  <h3 class="headline">Preffered tenant</h3>
                  <p><?php echo $prop_preffered_tenant; ?></p>
                  
                </div>
                
               
                <h3 class="headline">Accomodation Features</h3>
                <ul class="checked_list feature-list">
                    <?php 
                        foreach($prop_features as $key => $value){
                            echo '<li>'.$value.'</li>';
                        }
                    ?>
                </ul>
            <?php } ?>
            
                <div class="item-navigation">
                  <ul class="nav nav-tabs v2" role="tablist">
                    <li role="presentation"><a href="#map" aria-controls="map" role="tab" data-toggle="tab" class="active"><i class="fa fa-map"></i> <span class="hidden-xs">Map &amp; nearby</span></a></li>
                    <!--<li role="presentation"><a href="#streetview" aria-controls="streetview" role="tab" data-toggle="tab"><i class="fa fa-road"></i> <span class="hidden-xs">Street View</span></a></li>-->
                  </ul>
                 
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="map">
                      
                      <iframe src="map.php?prop_id=<?php echo $prop_id?>"  width="600" height="450" style="border:0;" allowfullscreen></iframe>
                      
                    </div>
                    
                  </div>
                </div> 
              </div>
            </div>
          </div>
          <div class="col-md-5 col-lg-4">
            <div id="sidebar" class="sidebar-right">
              <div class="sidebar_inner">
                <div id="feature-list" role="tablist">
                <div class="card">
                  <div class="card-header" role="tab" id="headingOne">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" style="color:#ea621e" href="#specification" aria-expanded="true" aria-controls="specification"> Specifications <i class="fa fa-caret-down float-right"></i> </a> </h4>
                  </div>
                  <div id="specification" class="panel-collapse collapse show" role="tabpanel">
                    <div class="card-body">
                      <table class="table v1">
                          <tr>
                          <td>Accomodation for</td>
                          <td><?php echo $indi_share;?></td>
                        </tr>
                        <tr>
                          <td>Price</td>
                          <td><?php echo 'R '.$price;?></td>
                        </tr>
                        <tr>
                          <td>Bedrooms</td>
                          <td><?php echo $bed;?></td>
                        </tr>
                        <tr>
                          <td>Bathrooms</td>
                          <td><?php echo $bath;?></td>
                        </tr>
                         <tr>
                          <td>Deposit</td>
                          
                          
                          <?php if($user_type_id=='2'){ ?>
                          <td><?php echo 'R'.$prop_deposit; ?></td>
                          <?php }else{ ?> 
                          <td><?php echo $prop_deposit; ?></td>
                          <?php } ?>
                          
                          
                        </tr>
                        
                         <tr>
                          <td>Rental method</td>
                          <td><?php echo $prop_rental_type.' rental';?></td>
                        </tr>
                        <?php if ($user_type_id=='2'){ ?>
                         <tr>
                          <td>Water</td>
                          <td><?php echo $prop_water_include;?></td>
                        </tr>
                        
                         <tr>
                          <td>Electricity</td>
                          <td><?php echo $prop_elec_include;?></td>
                        </tr>
                        <?php } ?>
                        <tr>
                          <td>Lease period</td>
                          <td><?php echo $prop_lease_period;?></td>
                        </tr>
                        
                        
                          
                        
                      </table>
                    </div>
                  </div>
                </div>
                </div>
                
                <?php
                require_once('MysqliDb.php');
                $db223 = new MysqliDb ('rent');
                $db223->where("user_id='$user_id'");
                $resu3 = $db223->get('agents'); 
                if(!empty($resu3)){
                   foreach($resu3 as $key=> $value3){
                       $cur_pic = $value3['agent_profile_pic'];
                   }
                   
                   $src ="agents/$user_id/profile/$cur_pic"; 
                   
                }else{
                    $cur_pic='dummy.jpg';
                    $src ="agents/Global_profile_pic/$cur_pic"; 
                }
                
                
                ?>
                
                
                <div class="card shadow">
                  <h5 class="subheadline mt-0  mb-0"> Added By</h5>
                  <div class="media">
                    <div class="media-left"> <a href="agent.php?id=<?php echo $user_id;?>"> <img class="media-object rounded-circle" src="<?php echo $src; ?>" width="64" height="64" alt=""> </a> </div>
                    <div class="media-body">
                      <h4 class="media-heading" ><a style="color:#ea621e" href="agent.php?id=<?php echo $user_id;?>"><?php echo $agent_name;?></a></h4>
                      <!--<p><a href="tel:<?php// echo $agent_tel; ?>"><i class="fa fa-phone" aria-hidden="true"></i> Call: <?php echo $agent_tel; ?></a></p>-->
                      <!--<p><a href="#"><i class="fa fa-globe fa-fw" aria-hidden="true"></i> <?php// echo $agent_email; ?></a></p>-->
                      <p><a href="agent.php?id=<?php echo $user_id;?>" class="btn btn-sm btn-light">View Profile</a></p>
                    </div>
                  </div>
                  <a href="#" class="btn btn-lg btn-primary btn-block" data-toggle="modal" data-target="#leadform">Contact <?php echo $agent_name;?> </a> </div>
           
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Lead Form Modal -->
<div class="modal fade  item-badge-rightm" id="leadform" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div class="media">
          <div class="media-left"><img src="<?php echo $src; ?>" width="60" class="img-rounded mt5" alt=""></div>
          <div class="media-body">
            <h4 class="media-heading">Chat about <?php echo $title; ?></h4>
            <?php echo $loc; ?> </div>
        </div>
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="chat_agent">
              <input hidden="hidden" type="text" id="agent_mail" name="agent_mail" value="<?php echo $agent_email; ?>"> 
          <div class="form-group">
            <label>Your Name</label>
            <input type="text" required="required" id="name" value="<?php echo $name ?>" name="name"  class="form-control" placeholder="Your Name">
          </div>
          <div class="form-group">
            <label>Your Email</label>
            <input type="email" id="email" name="email"  value="<?php echo $email ?>" required="required" class="form-control" placeholder="Your Email">
          </div>
          <div class="form-group">
            <label>Your Telephone</label>
            <input type="tel" required="required" id="phone" name="phone" class="form-control" placeholder="Your Telephone">
          </div>
          <div class="form-group">
            <label>Message</label>
            <textarea rows="4" id="message" name="message" required="required" class="form-control" placeholder="Please include any useful details, i.e. current status, availability for viewings, etc."></textarea>
          </div>
          <button type="submit" hidden="hidden" name="the_sub" id="the_sub"></button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link" data-dismiss="modal">Cancel</button>
        <button type="button" onclick="sub()" class="btn btn-primary">Send</button>
      </div>
    </div>
  </div>
</div>

<?php
if(isset($_SESSION['user_id'])){
  $name=$_SESSION['user_name'];
  $email=$_SESSION['user_email'];
}else{
  $name='';
  $email='';
}
?>

<!-- Email to friend Modal -->
<div class="modal fade item-badge-rightm" id="email-to-friend" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div class="media">
          <div class="media-left"> <img src="img/demo/property/thumb/1.jpg" width="60" class="img-rounded mt5" alt=""> </div>
          <div class="media-body">
            <h4 class="media-heading">Email friend about 2 bed semi-detached classic studio to rent</h4>
            Church street, Pretoria 0002 </div>
        </div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="send_friend">
          <div class="form-group">
            <label>Your Name</label>
            <input required="required" value="<?php echo $name?>" type="text" class="form-control" id="name" name="name" placeholder="Your Name">
          </div>
          <div class="form-group">
            <label>Your Email</label>
            <input required="required"  value="<?php echo $email?>" type="email" class="form-control" id="email" name="email" placeholder="Your Email"> 
          </div>
          <div class="form-group">
            <label>Friends Email</label>
            <input type="email" id="femail" name="femail" required="required"  class="form-control" placeholder="Friends Email">
          </div>
          <div class="form-group">
            <label>Message</label>
            <textarea required="required"  id="message" name="message" rows="4" class="form-control" placeholder="">I thought you might want to take a look at this accomodation to rent</textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link" data-dismiss="modal">Cancel</button>
        <button type="button" onclick="alert()" class="btn btn-primary">Send</button>
      </div>
    </div>
  </div>
</div>

<!-- Report Listing Modal -->
<div class="modal fade item-badge-rightm" id="report-listing" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div class="media">
          <div class="media-left"> <i class="fa fa-3x fa-exclamation-circle" aria-hidden="true"></i> </div>
          <div class="media-body">
            <h4 class="media-heading">Report Listing for 2 bed semi-detached classic studio to rent</h4>
            Church street, Pretoria 0002  </div>
        </div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="report">
          <div class="form-group">
            <label>Contact Name</label>
            <input required="required" value="<?php echo $name;?>" id="name2" name="name2" type="text" class="form-control" placeholder="Contact Name">
          </div>
          <div class="form-group">
            <label>Email Address</label>
            <input required="required" id="email2" value="<?php echo $email;?>"  name="email2" type="email" class="form-control" placeholder="Email Address">
          </div>
          <div class="form-group">
            <label>Nature of report</label>
            <select required="required" id="nature" name="nature" class="form-control">
              <option value="" disabled="disabled">Please Select</option>
              <option value="no_longer_available">Accomodation is no longer available</option>
              <option value="incorrect_price">Price listed is incorrect</option>
              <option value="incorrect_last_sold_price">Last sold price incorrect</option>
              <option value="incorrect_description">Accomodation description is inaccurate</option>
              <option value="incorrect_location">Accomodation location is incorrect</option>
              <option value="incorrect_content">Problem with photos, floorplans, etc.</option>
              <option value="inappropriate_video">Problem with the video</option>
              <option value="agent_not_contactable">Agent is not contactable</option>
              <option value="incorrect_running_costs">Running costs is displaying inaccurate values</option>
              <option value="other">Other (please specify)</option>
            </select>
          </div>
          <div class="form-group">
            <label>Description of content issue </label>
            <textarea  id="description" name="description" rows="4" class="form-control" placeholder="Please provide as much information as possible..."></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link" data-dismiss="modal">Cancel</button>
        <button type="button" onclick="alert()" class="btn btn-primary">Report Error</button>
      </div>
    </div>
  </div>
</div>

<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

    <!-- Background of PhotoSwipe. 
         It's a separate element, as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>

    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">

        <!-- Container that holds slides. PhotoSwipe keeps only 3 slides in DOM to save memory. -->
        <!-- don't modify these 3 pswp__item elements, data is added later on. -->
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>

        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
        <div class="pswp__ui pswp__ui--hidden">

            <div class="pswp__top-bar">

                <!--  Controls are self-explanatory. Order can be changed. -->

                <div class="pswp__counter"></div>

                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                <button class="pswp__button pswp__button--share" title="Share"></button>

                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                <!-- Preloader demo https://codepen.io/dimsemenov/pen/yyBWoR -->
                <!-- element will get class pswp__preloader--active when preloader is running -->
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                      <div class="pswp__preloader__cut">
                        <div class="pswp__preloader__donut"></div>
                      </div>
                    </div>
                </div>
            </div>

            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div> 
            </div>

            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
            </button>

            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
            </button>

            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>

          </div>

        </div>

</div>
<script type="text/javascript">
// Photoswipe
    //$( document ).ready(function() {
    

    var initPhotoSwipeFromDOM = function(gallerySelector) {
        var parseThumbnailElements = function(el) {
		console.log(el);
            var thumbElements = $(el).closest(main_gallery).find('figure'),
                numNodes = thumbElements.length,
                items = [],
                figureEl,
                linkEl,
                size,
                item;

            for (var i = 0; i < numNodes; i++) {

                figureEl = thumbElements[i]; // <figure> element

                // include only element nodes 
                if (figureEl.nodeType !== 1) {
                    continue;
                }

                linkEl = figureEl.children[0]; // <a> element

                size = linkEl.getAttribute('data-size').split('x');

                // create slide object
                item = {
                    src: linkEl.getAttribute('href'),
                    w: parseInt(size[0], 10),
                    h: parseInt(size[1], 10)
                };



                if (figureEl.children.length > 1) {
                    // <figcaption> content
                    item.title = figureEl.children[1].innerHTML;
                }

                if (linkEl.children.length > 0) {
                    // <img> thumbnail element, retrieving thumbnail url
                    item.msrc = linkEl.children[0].getAttribute('src');
                }

                item.el = figureEl; // save link to element for getThumbBoundsFn
                items.push(item);
            }

            return items;
        };

        // find nearest parent element
        var closest = function closest(el, fn) {
            return el && (fn(el) ? el : closest(el.parentNode, fn));
        };

        // triggers when user clicks on thumbnail
        var onThumbnailsClick = function(e) {
            e = e || window.event;
            e.preventDefault ? e.preventDefault() : e.returnValue = false;

            var eTarget = e.target || e.srcElement;

            // find root element of slide
            var clickedListItem = closest(eTarget, function(el) {
                return (el.tagName && el.tagName.toUpperCase() === 'FIGURE');
            });

            if (!clickedListItem) {
                return;
            }
            var clickedGallery = clickedListItem.parentNode,
                childNodes = $(clickedListItem).closest(main_gallery).find('figure'),
                numChildNodes = childNodes.length,
                nodeIndex = 0,
                index;

            for (var i = 0; i < numChildNodes; i++) {
                if (childNodes[i].nodeType !== 1) {
                    continue;
                }

                if (childNodes[i] === clickedListItem) {
                    index = nodeIndex;
                    break;
                }
                nodeIndex++;
            }
            if (index >= 0) {
                // open PhotoSwipe if valid index found
                openPhotoSwipe(index, clickedGallery);
            }
            return false;
        };

        var openPhotoSwipe = function(index, galleryElement, disableAnimation) {
            var pswpElement = document.querySelectorAll('.pswp')[0],
                gallery,
                options,
                items;

            items = parseThumbnailElements(galleryElement);

            // define options (if needed)
            options = {
                history: false,
                bgOpacity: 0.8,
                loop: false,
                barsSize: {
                    top: 0,
                    bottom: 'auto'
                },

                // define gallery index (for URL)
                galleryUID: $(galleryElement).closest(main_gallery).attr('data-pswp-uid'),

                getThumbBoundsFn: function(index) {
                    // See Options -> getThumbBoundsFn section of documentation for more info
                    var thumbnail = document.querySelectorAll(main_gallery+' img')[index],
                        //var thumbnail = items[index].el.getElementsByTagName('img')[0], // find thumbnail
                        pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
                        rect = thumbnail.getBoundingClientRect();

                    return {
                        x: rect.left,
                        y: rect.top + pageYScroll,
                        w: rect.width
                    };
                }

            };

            options.index = parseInt(index, 10);

            // exit if index not found
            if (isNaN(options.index)) {
                return;
            }

            if (disableAnimation) {
                options.showAnimationDuration = 0;
            }

            // Pass data to PhotoSwipe and initialize it
            gallery = new PhotoSwipe(pswpElement, PhotoSwipeUI_Default, items, options);
            gallery.init();
			gallery.shout('helloWorld', 'John' /* you may pass more arguments */);



            var totalItems = gallery.options.getNumItemsFn();

            function syncPhotoSwipeWithOwl() {
                var currentIndex = gallery.getCurrentIndex();
                galleryTop.slideTo(currentIndex);
                if (currentIndex == (totalItems - 1)) {
                    $('.pswp__button--arrow--right').attr('disabled', 'disabled').addClass('disabled');
                } else {
                    $('.pswp__button--arrow--right').removeAttr('disabled');
                }
                if (currentIndex == 0) {
                    $('.pswp__button--arrow--left').attr('disabled', 'disabled').addClass('disabled');
                } else {
                    $('.pswp__button--arrow--left').removeAttr('disabled');
                }
            };
            gallery.listen('afterChange', function() {
                syncPhotoSwipeWithOwl();
            });
            syncPhotoSwipeWithOwl();
        };

        // loop through all gallery elements and bind events
        var galleryElements = document.querySelectorAll(gallerySelector);

        for (var i = 0, l = galleryElements.length; i < l; i++) {
            galleryElements[i].setAttribute('data-pswp-uid', i + 1);
            galleryElements[i].onclick = onThumbnailsClick;
        }
    };
    //});
    
    var main_gallery = '.gallery-top';
    var galleryTop = new Swiper(main_gallery, {
      spaceBetween: 10,
	  lazy: {
		loadPrevNext: true,
	  },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
	  }
	  ,on: {
			init: function(){
				initPhotoSwipeFromDOM(main_gallery);
			},
		}
    });
    var galleryThumbs = new Swiper('.gallery-thumbs', {
      spaceBetween: 10,
	  centeredSlides: true,
	  slidesPerView: 5,
      touchRatio: 0.2,
      slideToClickedSlide: true,
    });
    galleryTop.controller.control = galleryThumbs;
    galleryThumbs.controller.control = galleryTop;	
    
  
    
  </script>
</body>
</html>