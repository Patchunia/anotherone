<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/sidr/jquery.sidr.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyAZlUmAOz-IszdSYbZDCnAvco2fya_VRp4"></script>
 <script>
 $( document ).ready(function() {
 var input = document.getElementById('autocomplete');
      var autocomplete = new google.maps.places.Autocomplete(input);
      
      var input = document.getElementById('autocomplete');
var options = {
  componentRestrictions: {country: 'za'}
};

autocomplete = new google.maps.places.Autocomplete(input, options);

$('#pb').click();

});

function switch_agen(id){
         if(id=='1'){
             $('#land').hide();
                $('#agen').show();
                $('#user_type_search').val('agent');
         }else{
             $('#land').show();
            $('#agen').hide();
            $('#user_type_search').val('landlord');
         }
     }
     
      $( document ).ready(function() {
     $('#land').hide();
     $('#user_type_search').hide();
     $('#agen').show();
     
     $('#user_type_search').val('agent');
      });

    
 </script>
<body>
<div id="main">
<?php include('navbar.php'); ?>
 
</div>
<div class="container">
  <div class="row justify-content-md-center">
    <div class="col col-lg-12 col-xl-10">
     
      <div class="page-header">
        <h2 style="color:#ea621e">Accomodation to rent</h2>
      </div>
    </div>
  </div>
</div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-lg-12 col-xl-10">
        
            <div class="clearfix"></div>
            <div class="item-listing grid">
              <div class="row">
              <?php
               
                require_once('MysqliDb.php');
              
                  $db1100 = new MysqliDb ('rentzywp_rentzar');
                  $result100=$db1100->rawQuery("select user_id from users where user_type_id='2'");
                  if(!empty($result100)){
                      $landlords_id=[];
                      foreach($result100 as $key100 => $value100){
                          $id = $value100['user_id'];
                          $landlords_id[] = $id;
                      }
                      
                      $landlords_id = implode(',',$landlords_id);
                  }else{
                      echo '<h4>No search results found </h4>';
                  }
                    
                $db1 = new MysqliDb ('rentzywp_rentzar');
                 
                $result=$db1->rawQuery("select * from property where user_id in ($landlords_id) order by prop_id desc");
              
                  
                if(!empty($result)){
                    
                  foreach ($result as $key => $value) {
                    $image_name    =$value['prop_main'];
                    $price         =$value['prop_price'];
                    $prop_id       =$value['prop_id'];
                    $title         =$value['prop_title'];
                    $loc           =$value['prop_loc'];
                    $bed           =$value['prop_bed'];
                    $bath          =$value['prop_bath'];
                    $user_id       =$value['user_id'];


                    $main_image_path = 'agents/'.$user_id.'/property/'.$prop_id.'/main/'.$image_name;
                   
                    if (!file_exists($main_image_path)) {
                      $main_image_path = 'agents/stock_image.png';

                    } ?>
                  <div class="col-lg-6">
                    <div class="item">
                      <div class="item-image"><a href="property_single.php?id=<?php echo $prop_id; ?>"><img src="<?php echo $main_image_path ?>" class="img-fluid" alt="">
                        <div class="item-badges">
                         <div class="item-badge-left">Available</div>
                          <!-- <div class="item-badge-right">For Sale</div> -->
                        </div>
                        </a> <!--<a href="#" class="save-item"><i class="fa fa-star"></i></a> --> </div>
                      <div class="item-info">
                        <h3 class="item-title"><?php echo $title; ?></h3>
                        <div class="item-location"><i class="fa fa-map-marker"></i> <?php echo $loc; ?></div>
                        <div class="item-details-i"> <span class="bedrooms" data-toggle="tooltip" title="<?php echo 'R '.$price; ?>"><?php echo 'R '.$price; ?></span>&nbsp; <span class="bedrooms" data-toggle="tooltip" title="<?php echo $bed; ?> Bedroom(s)"><?php echo $bed; ?><i class="fa fa-bed"></i></span>&nbsp; <span class="bathrooms" data-toggle="tooltip" title="<?php echo $bath; ?> Bathroom(s)"><?php echo $bath; ?> <i class="fa fa-bath"></i></span> </div>
                      </div>
                    </div>
                  </div>                    
            <?php }
                  
              }else{
                  
                      echo '<h4>No search results found for <div style="color:#ea621e"> "'.$address.'"</div></h4>';
              }
              ?>



              </div>
             
            </div>
            
          </div>
        </div>  
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<script>
R(document).ready(function() {
  R('#toggle-filters').sidr({
    side: 'left',
    displace : false,
    renaming : false,
    name: 'sidebar',
    source: function() {
      AOS.refresh();
    },
    
  });
});
</script>
</body>
</html>