<?php
session_start();
if(!isset($_SESSION['user_name'])){
    exit();
}
if(!isset($_SESSION)){
    header("Location:index.php");
    exit();
}else{
     $user_id = $_SESSION['user_id'];
    
    require_once('MysqliDb.php');
    $db223 = new MysqliDb ('rentzywp_rentzar');
    $db223->where("user_id='$user_id'");
    $resu3 = $db223->get('agents'); 
    if(!empty($resu3)){
       foreach($resu3 as $key=> $value3){
           $cur_pic = $value3['agent_profile_pic'];
       }
    }else{
        $cur_pic='';
    }
}

if(isset($_POST['submit'])){
    $pic = $_FILES['pic']['name'];
   
      if($pic!=''){

          $target_dir = 'agents/'.$user_id.'/profile/';
          
          //clean folder
          $files_in_folder = glob($target_dir.'/*'); // get all file names
            foreach($files_in_folder as $gor_file){ // iterate files
              if(is_file($gor_file))
                unlink($gor_file); // delete file
            }


          $target_file = $target_dir . basename($_FILES["pic"]["name"]);
          $uploadOk = 1;
          $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

         // Check if image file is a actual image or fake image         
          $check = getimagesize($_FILES["pic"]["tmp_name"]);
          if($check !== false) {
              //echo "File is an image - " . $check["mime"] . ".";
              $uploadOk = 1;
          }else{
            header("Location:404_error.php?from=my_propic&error_list=1");
            exit();
          } 

          if (move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file)) {
              
              
              
              require_once('MysqliDb.php');
                $db22 = new MysqliDb ('rentzywp_rentzar');
                $db22->where("user_id='$user_id'");
                $resu = $db22->get('agents');
                $data2['agent_profile_pic'] = $pic;
                if(!empty($resu)){
                    $db2 = new MysqliDb ('rentzywp_rentzar');
                    $db2->where("user_id='$user_id'");
                    $db2->update('agents',$data2);
                }else{
                    $data2['user_id'] = $user_id;
                    $db2 = new MysqliDb ('rentzywp_rentzar');
                    $db2->insert('agents',$data2);
                }
                
                header("Location:success.php?from=my_propic");
              exit();
              
          } else {
              header("Location:404_error.php?from=my_propic&error_list=1");
              exit();
          }
          
        }
 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/tinymce/tinymce.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
 
<body>
<div id="main">
<?php include('navbar.php'); ?>

 

<div class="clearfix"></div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        <div class="row has-sidebar">
          <div class="col-md-5 col-lg-4 col-xl-4">
              <div id="sidebar" class="sidebar-left">
                <div class="sidebar_inner">
                  <div class="list-group no-border list-unstyled">
                    
                  <?php if($_SESSION['user_type_id']!='' && $_SESSION['user_type_id']==2){ ?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                   
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_profile_pic.php" class="list-group-item active"><i class="fa fa-fw fa-user"></i> My Profile picture</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                    
                 <?php }else{?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add2.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                    
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                 <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          <div class="col-md-7 col-lg-8 col-xl-8">
            <div class="page-header bordered">
              <h1>My profile picture <small>Manage your public profile picture</small></h1>
            </div>
            <form id="profile" method="post" action="my_profile_pic.php" enctype="multipart/form-data">
                
                
                <?php 
                
                    if($cur_pic!=''){
                        $src ="agents/$user_id/profile/$cur_pic"; 
                       
                        ?>
                  
                    <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Your current photo</label>
                        <img src="<?php echo $src; ?>" class="img-fluid img-responsive" width="200px" height="200px">
                      </div>
                    </div> 
                  </div> 
                <?php
                    }
                ?>
                
               
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Upload photo</label>
                    <input type="file" id="pic" required="required" name="pic" class="form-control form-control-lg" accept="image/*">
                  </div>
                </div> 
              </div> 
              
              
            
              <div class="form-group action">
                <button type="submit" name="submit" id="submit" class="btn btn-md btn-primary">Update photo</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<script>
var placeSearch, autocomplete;
var componentForm = {
	//street_number: 'short_name',
	//route: 'long_name',
	locality: 'long_name',
	administrative_area_level_1: 'long_name',
	country: 'long_name',
	postal_code: 'long_name'
};

function initAutocomplete() {
	autocomplete = new google.maps.places.Autocomplete((document.getElementById('autocomplete')), {types: ['geocode']});
	autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
	var place = autocomplete.getPlace();
	for (var component in componentForm) {
		document.getElementById(component).value = '';
		document.getElementById(component).disabled = false;
	}
	
	for (var i = 0; i < place.address_components.length; i++) {
		var addressType = place.address_components[i].types[0];
		if (componentForm[addressType]) {
			var val = place.address_components[i][componentForm[addressType]];
			document.getElementById(addressType).value = val;
		}
	}
}
</script> 
<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete" async defer></script> 
<script>
	tinymce.init({
		selector: '.text-editor',
		height: 200,
		menubar: false,
		branding: false,
		plugins: [
			'lists link image preview',
		],
		toolbar: 'undo redo | link | formatselect | bold italic underline  | alignleft aligncenter alignright alignjustify | bullist numlist'
	});
        </script>
</body>
</html>