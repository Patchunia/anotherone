<?php
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']!=''){
        header('Location:index.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<style>
    .loginBtn {
  box-sizing: border-box;
  position: relative;
  /* width: 13em;  - apply for fixed size */
  margin: 0.2em;
  padding: 0 15px 0 46px;
  border: none;
  text-align: left;
  line-height: 34px;
  white-space: nowrap;
  border-radius: 0.2em;
  font-size: 16px;
  color: #FFF;
}
.loginBtn:before {
  content: "";
  box-sizing: border-box;
  position: absolute;
  top: 0;
  left: 0;
  width: 34px;
  height: 100%;
}
.loginBtn:focus {
  outline: none;
}
.loginBtn:active {
  box-shadow: inset 0 0 0 32px rgba(0,0,0,0.1);
}


/* Facebook */
.loginBtn--facebook {
  background-color: #4C69BA;
  background-image: linear-gradient(#4C69BA, #3B55A0);
  /*font-family: "Helvetica neue", Helvetica Neue, Helvetica, Arial, sans-serif;*/
  text-shadow: 0 -1px 0 #354C8C;
}
.loginBtn--facebook:before {
  border-right: #364e92 1px solid;
  background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/14082/icon_facebook.png') 6px 6px no-repeat;
}
.loginBtn--facebook:hover,
.loginBtn--facebook:focus {
  background-color: #5B7BD5;
  background-image: linear-gradient(#5B7BD5, #4864B1);
}

#loginBtn{
    display:block;
}
#logoutBtn{
    display:none;
}
#btn-confirm{
    display:none;
}
#moda{
    display:none;
}
.hidden{
    display:none !important;
    /*background-color:red;*/
}

</style>

<script>
$( document ).ready(function() {
    
   

    $('#sign').on('submit', function (e) {
        e.preventDefault();
        var form_data= $('#sign').serialize();
        $.ajax({
            type: 'post',
            url: 'json.php?type=signin',
            data: form_data,
            success: function (response) {
                if(response=='1'){
                    window.location.href="my_profile.php";
                }else{
                     window.location.href="404_error.php?from=signin";
                }
            }
      });
    });
});
</script>
<body>
<!----------------------------------------------------- 
                        FACEBOOK LOGIN
------------------------------------------------------->
<script>
var fb_array = [];

$( document ).ready(function() {
    
    setTimeout(function() {
        $('#lbtn').click();
        //$("div#myModal").removeClass("hidden");
    }, 900);
    
    setTimeout(function() {
        $("#myModal").removeClass("hidden");
    }, 1100);
    
     
    
 
    
  $('#myModal').modal({
      backdrop: 'static',
      keyboard: false
  })
  
  

  document.getElementById('loginBtn').addEventListener('click', function() {
    
      FB.login(function(response) {
        if (response.authResponse) {
           
          $('#loginBtn').hide();
          $('#logoutBtn').show();
          getUserData('M');
        }
      }, {scope: 'email,public_profile', return_scopes: true});
    }, false);

    document.getElementById('logoutBtn').addEventListener('click', function() {
      //do the login
        FB.logout(function(response) {
            //console.log(response);
            fb_array =[];
              $('#loginBtn').show();
          $('#logoutBtn').hide();
          $('#myModal').modal('hide');
        });
    });
    
    document.getElementById('lbtn').addEventListener('click', function() {
    
      if (typeof fb_array !== 'undefined' && fb_array.length > 0) {
          
          FB.logout(function(response) {
                //console.log(response);
                fb_array =[];
                 $('#loginBtn').show();
                $('#logoutBtn').hide();
                $('#myModal').modal('hide');
                
               
            });
      }else{
          window.location.href="https://www.rentzar.co.za/signin.php";
          $('#myModal').modal('hide');
      }
        
    });



      window.fbAsyncInit = function() {
       
        FB.init({
          appId      : '150652572264435',
          xfbml      : true,
          version    : 'v2.2'
        });
       
        FB.getLoginStatus(function(response) {

          if (response.status === 'connected') {
            //alert('im here connected');
            $('#loginBtn').hide();
            $('#logoutBtn').show();
            getUserData('L');
            
          } else {
            
            $('#loginBtn').show();
            $('#logoutBtn').hide();
          }
        });
        
    };

    (function(d, s, id){
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {return;}
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.com/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    
    
        
});


function getUserData(indi) {
    
  FB.api('/me', {fields: 'email,first_name,last_name'},  function(response) {
      //console.log(response);
       
      fb_array = response;
      //alert(response.email+' '+response.first_name+' '+response.last_name);
      
      //alert('im here at getUserData');
      
      $.ajax({
            type: 'post',
            url: 'json.php?type=signin_fb',
            data: response,
            success: function (response) {
                if(response=='1'){
               
                    window.location.href="my_profile.php";
                }
                if(response=='2'){
                    
                   // alert('im here at calling reg_fb');
                    register_fb();
                }
                //else{
                     //window.location.href="404_error.php?from=signin";
                //}
            }
        });
       
  });
  
}

function register_fb(){
    //show modal
    //alert('im here at reg_fb opening modal');
    var nn = fb_array.first_name;
    var nn2 = fb_array.last_name;
    var nn3 = nn+' '+nn2;
    $('#useNames').empty();
    $('#useNames').append(nn3);
    $('#moda').click();
}

function register_fb2(reg_type){
//alert('im here at reg_fb2');
    // console.log(fb_array);
    $.ajax({
        type: 'post',
        url: 'json.php?type=register_fb&reg_type='+reg_type,
        data: fb_array,
        success: function (response) {
           // alert('im here about to show response on reg_fb2');
            if(response=='1'){
      //      alert('reg_fb2 response is 1');
                sign_to_fb();
                window.location.href="my_profile.php";
                $('#myModal').modal('hide');
            }else{
        //    alert('reg_fb2 response is not 1');
            }
        }
    });
    
}

function sign_to_fb(){
//alert('im here sign_to_fb');
  $.ajax({
      type: 'post',
      url: 'json.php?type=signin_fb',
      data: fb_array,
      success: function (response) {
  //    alert('im here about to show resp sign_to_fb');
          if(response=='1'){
    //     alert('sign_to_fb is 1');
              window.location.href="my_profile.php";
          }
          if(response=='2'){
      //    alert('sign_to_fb is 2 and calling reg_fb');
              register_fb();
          }
          if(response!='1' && response!='2'){
        //    alert('sign_to_fb is not 2 and not 1');
          }
          //else{
               //window.location.href="404_error.php?from=signin";
          //}
      }
  });
}

</script>
   
<div id="main">
<?php include('navbar.php'); ?>


<!--------------------------------------------------------------------

            Facebook register as modal
---------------------------------------------------------------------->

<!-- Modal -->
<div id="myModal" class="modal fade hidden" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
     
      </div>
      <div class="modal-body">
        <b><p><div id="useNames"></div> welcome to RENTZAR,would you like to register as a Tenant or Landlord ?</p></b>
      </div>
      <div class="modal-footer">
          <button type="button" onclick="register_fb2('1');" class="btn btn-primary">Tenant</button>
          <button type="button" onclick="register_fb2('2');" class="btn btn-primary">Landlord</button>
          
        <button type="button" id="lbtn"  data-dismiss="modal" class="btn btn-danger">Cancel</button>
      </div>
    </div>

  </div>
</div>

 


<div id="content" class="property-single">
    
  <div class="container">
        <div class="page-header"> <h1 style="color:#ea621e">Sign in / register</h1> </div>
    <!----------------------------------------------------- 
                        FACEBOOK LOGIN
    ------------------------------------------------------->
  
 
<button   class="loginBtn loginBtn--facebook" data-max-rows="1" data-size="medium" id="loginBtn">Login with Facebook</button>

<button  class="loginBtn loginBtn--facebook" data-max-rows="1" data-size="medium" id="logoutBtn">Log Out</button>


    <form id="sign">
     <br> <div class="form-group">
        <label for="email">Email address</label>
        <input type="email" id="email" name="email"  required="required" class="form-control form-control-lg" placeholder="Email">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password"  required="required" class="form-control form-control-lg" placeholder="Password">
      </div>
      <p class="text-lg-left"><a href="forgot-password.php">Forgot Password</a></p>
      <p class="text-lg-left"><a href="register.php">Create / register account</a></p>
      <button type="submit" class="btn btn-primary btn-lg">Sign In</button>
    </form>
  </div>
</div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<button type="button" id ="moda" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>
</body></html>