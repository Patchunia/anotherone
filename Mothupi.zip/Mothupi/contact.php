<?php
 
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>
$( document ).ready(function() {
  
    $('#contact').on('submit', function (e) {

        e.preventDefault();
        var form_data= $('#contact').serialize();
       
        $.ajax({
            type: 'post',
            url: 'json.php?type=contact',
            data: form_data,
            success: function (response) {
                if(response=='1'){
                    window.location.href="success.php?from=contact";
                }else{
                     window.location.href="404_error.php?from=contact";
                }
                
            }
      });
    });
});
</script>
<?php
if(isset($_SESSION['user_id'])){
  $name=$_SESSION['user_name'];
  $email=$_SESSION['user_email'];
}else{
  $name='';
  $email='';
}
?>
<body>
<div id="main">
<?php include('navbar.php'); ?>
<div id="content" class="property-single">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        
        <div class="page-header">
        <?php 
            if(isset($_REQUEST['t'])){
                if($_REQUEST['t']=='f'){
                    $heading = 'Thank you for stopping by RENTZAR!';
                    $msg = 'Was this site helpful ?';
                }
            }else{
                $heading = 'Contact Us';
                $msg ='Message';
            }
        ?>    
        <h1 style="color:#ea621e"><?php echo $heading; ?></h1>
        </div>
        <div style="font-weight:bold" class="row col-sm-12 col-md-12 col-lg-12 col-xl-12">
            
                <div class="col-sm-12 col-md-12 col-lg-4 col-xl-4">
                    <label>General - </label>info@rentzar.co.za
                </div>
                 <div class="col-sm-12 col-md-12 col-lg-4 col-xl-4">
                    <label>Admin - </label>lloyd@rentzar.co.za
                </div>
                <!--<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4">-->
                <!--    <label>Admin - </label>mcebo@rentzar.co.za-->
                <!--</div>-->
          
        </div><br>
        <div class="row has-sidebar">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card">
              <form id="contact">
                <div class="form-group">
                  <label for="contact_name">Your Name</label>
                  <input required="required" type="text" class="form-control" name="contact_name" value="<?php echo $name;?>" placeholder="Your Name">
                </div>
                <div class="form-group">
                  <label for="contact_email">Your Email</label>
                  <input required="required" value="<?php echo $email;?>" type="email" class="form-control" name="contact_email" placeholder="Your Email">
                </div>
                <div class="form-group">
                  <label for="contact_type">Contact type</label>
                  
                  <?php 
                    if(isset($_REQUEST['t'])){
                        if($_REQUEST['t']=='f'){ ?>
                        
                            <select required="required" class="form-control" name="contact_type">
                              <option value="Feedback" selected="selected">Feedback</option>
                             
                          </select>
                    <?php 
                        }
                    }else{
                       
                
                ?> 
                  <select required="required" class="form-control" name="contact_type">
                      <option value="" selected="selected" disabled="disabled">--select--</option>
                      <option value="b">Business</option>
                      <option value="e" >Enquiries</option>
                  </select>
                <?php } ?>
                </div>
                <div class="form-group">
                  <label for="contact_message">Message</label>
                  <textarea required="required" rows="4" class="form-control" name="contact_message" placeholder="<?php echo $msg;?>"></textarea>
                </div>
                <button type="submit" id="contact" name="contact"class="btn btn-lg btn-primary">Send Message</button>
              </form>
            </div>
          </div>
       

          <!--<div class="col-md-7 col-lg-8 col-xl-8">
          <!--  <div class="row">-->
          <!--    <div class="col-md-6">-->
          <!--      <h3 class="subheadline mt0" style="color:#ea621e">Head Office</h3>-->
          <!--      <address>-->
          <!--      <strong>RentZar, Inc.</strong><br>-->
          <!--      433 Church Street, Central<br>-->
          <!--      Pretoria, ZA 0002<br>-->
          <!--      <abbr title="Phone">P:</abbr> (012) 456-7890-->
          <!--      </address>-->
          <!--    </div>-->
          <!--    <div class="col-md-6">-->
          <!--      <h3 class="subheadline mt0" style="color:#ea621e">Office Hours</h3>-->
          <!--      <ul class="list-unstyled opening-hours">-->
          <!--        <li>Monday - Friday<span class="float-right">9:00-22:00</span></li>-->
          <!--        <li>Saturday <span class="float-right">14:00-23:30</span></li>-->
          <!--        <li>Sunday <span class="float-right">Closed</span></li>-->
          <!--      </ul>-->
          <!--    </div>-->
          <!--  </div>-->
          <!--  <h3 class="subheadline mt0">Office Location</h3>-->
          <!--  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3593.730864738335!2d28.185883014652614!3d-25.746412383643744!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e9562121cebadcb%3A0xc223b654d2e8d761!2sChurch+Square!5e0!3m2!1sen!2sza!4v1515161538181"  width="600" height="450" style="border:0;" allowfullscree></iframe>-->
          <!--</div>--> 
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>

</body></html>