<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="main">
<?php include('navbar.php'); ?>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-lg-8">
        <div class="error-template text-center"> <i class="fa fa-check fa-5x text-success mb50 animated zoomIn"></i>
        <?php 
            if(isset($_REQUEST['from'])){
                if($_REQUEST['from']=='suggestion'){
                    $msg='Suggestion successfully sent';
                    $link='suggestion.php';
                }
                if($_REQUEST['from']=='contact'){
                    $msg='Message successfully sent';
                    $link='contact.php';
                }
                if($_REQUEST['from']=='forgot'){
                    $msg='Email match, we have sent a reset link';
                    $link='index.php';
                }
                if($_REQUEST['from']=='reset'){
                    $msg='Password successfully reset';
                    $link='index.php';
                }
                if($_REQUEST['from']=='profile'){
                    $msg='Profile successfully updated';
                    $link='my_profile.php';
                }
                if($_REQUEST['from']=='inline_change'){
                    $msg='Passsword successfully updated';
                    $link='my_profile.php';
                }
                if($_REQUEST['from']=='add_listing'){
                    $msg='Property successfully updated';
                    $link='my_listing_add.php';
                }
                if($_REQUEST['from']=='register'){
                    $msg='Successfully registered, please refer to your email for confirmation.';
                    $link='index.php';
                }
                
                if($_REQUEST['from']=='my_propic'){
                    $msg='Successfully uploded your profile picture.';
                    $link='my_profile_pic.php';
                }
                
                if($_REQUEST['from']=='chat_agent'){
                    $id = $_REQUEST['id'];
                    $msg='You contact message was successfully sent.';
                    $link='property_single.php?id='.$id.'';
                }
                
                if($_REQUEST['from']=='contact_agent'){
                    $id = $_REQUEST['id'];
                    $msg='You contact message was successfully sent.';
                    $link='agent.php?id='.$id.'';
                }
            }else{
                $msg='Congratulations';
                $link='index.php';
            }
        ?>
          <h3 class="main-title centered"><span><?php echo $msg; ?></span></h3>
          <div class="main-title-description"> RentZar thanks you! </div>
          <div class="error-actions"><a href="<?php echo $link; ?>" class="btn btn-primary btn-lg">Continue </a> </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>

</body></html>