<?php
 session_start();if(empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] == "off"){$redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];header('HTTP/1.1 301 Moved Permanently');header('Location: ' . $redirect);exit();
}if(isset($_SESSION['user_id'])){$logged=1;}else{$logged=0;}
 ?>
<!DOCTYPE html>
<html lang="en">
    
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>RentZAR</title>

<!-- Bootstrap
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/swiper/css/swiper.min.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" /> -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed 
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/swiper/js/swiper.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>  -->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyAZlUmAOz-IszdSYbZDCnAvco2fya_VRp4"></script>
 
 <script>
 var log_stat = '<?php echo $logged; ?>';
function switch_agen(id){
if(id=='1'){
$('#land').hide();
$('#agen').show();
$('#user_type_search').val('agent');
}else{
$('#land').show();
$('#agen').hide();
$('#user_type_search').val('landlord');
}
}
$( document ).ready(function() {$('#land').hide();$('#user_type_search').hide();$('#agen').show();$('#user_type_search').val('agent');var input = document.getElementById('autocomplete');var autocomplete = new google.maps.places.Autocomplete(input);var input = document.getElementById('autocomplete');var options = {componentRestrictions: {country: 'za'}};autocomplete = new google.maps.places.Autocomplete(input, options);});
</script>
<body>
<div id="main">
<?php include('navbar.php'); ?>
<div class="home-search">
<div class="main search-form">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col-md-12 col-lg-10">
        <div class="heading">
          <h2>Find your new home</h2>
          <h3>We will help you to find the best places to spend time in any city across South Africa.</h3>
        </div>
        <form action="property_grid.php" method="post">
            <input type="text" required="required" id="user_type_search" name="user_type_search" hidden="hidden">
          <div class="card">
              <div class="row">
                  <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2">
                    <div class="form-group">
                        <label style="color:white">I am a potential</label>
                    </div>
                  </div>
                  
                  <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10">
                    <div class="form-group">
                        <button type="button" onclick="switch_agen(1);" class="btn btn-primary">Tenant <span id="agen" class="fa fa-check"></span></button>
                        <button type="button" onclick="switch_agen(2);" class="btn btn-primary">Landlord <span id="land" class="fa fa-check"></span></button>
                    </div>
                  </div>
                   
              </div>
            <div class="row">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="form-group">
                  <input type="text" required="required" id="autocomplete" name="address"  class="form-control form-control-lg" placeholder="City,Address,Province.">
                </div>
              </div>
            </div>
<div class="row">
  <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3">
    <div class="form-group">
      <label style="color:#ea621e">Min price</label>
      <select required="required" name="min_price" class="form-control form-control-lg ui-select" >
        <option value="0">Any</option>
        <option value="1000">R 1&nbsp;000</option>
        <option value="1500">R 1&nbsp;500</option>
        <option value="2000">R 2&nbsp;000</option>
        <option value="2500">R 2&nbsp;500</option>
        <option value="3000">R 3&nbsp;000</option>
        <option value="3500">R 3&nbsp;500</option>
        <option value="4000">R 4&nbsp;000</option>
        <option value="4500">R 4&nbsp;500</option>
        <option value="5000">R 5&nbsp;000</option>
        <option value="6000">R 6&nbsp;000</option>
        <option value="7000">R 7&nbsp;000</option>
        <option value="8000">R 8&nbsp;000</option>
        <option value="9000">R 9&nbsp;000</option>
        <option value="10000">R 10&nbsp;000</option>
        <option value="11000">R 11&nbsp;000</option>
        <option value="12000">R 12&nbsp;000</option>
        <option value="13000">R 13&nbsp;000</option>
        <option value="14000">R 14&nbsp;000</option>
        <option value="15000">R 15&nbsp;000</option>
        <option value="16000">R 16&nbsp;000</option>
        <option value="17000">R 17&nbsp;000</option>
        <option value="18000">R 18&nbsp;000</option>
        <option value="19000">R 19&nbsp;000</option>
        <option value="20000">R 20&nbsp;000</option>
        <option value="25000">R 25&nbsp;000</option>
        <option value="30000">R 30&nbsp;000</option>
        <option value="35000">R 35&nbsp;000</option>
        <option value="40000">R 40&nbsp;000</option>
        <option value="50000">R 50&nbsp;000</option>
        <option value="60000">R 60&nbsp;000</option>
        <option value="70000">R 70&nbsp;000</option>
        <option value="80000">R 80&nbsp;000</option>
      </select>
    </div>
  </div>
  <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3">
    <div class="form-group">
    <label style="color:#ea621e">Max price</label>
      <select required="required" name="max_price" class="form-control form-control-lg ui-select" >
        <option value="0">Any</option>
        <option value="1000">R 1&nbsp;000</option>
        <option value="1500">R 1&nbsp;500</option>
        <option value="2000">R 2&nbsp;000</option>
        <option value="2500">R 2&nbsp;500</option>
        <option value="3000">R 3&nbsp;000</option>
        <option value="3500">R 3&nbsp;500</option>
        <option value="4000">R 4&nbsp;000</option>
        <option value="4500">R 4&nbsp;500</option>
        <option value="5000">R 5&nbsp;000</option>
        <option value="6000">R 6&nbsp;000</option>
        <option value="7000">R 7&nbsp;000</option>
        <option value="8000">R 8&nbsp;000</option>
        <option value="9000">R 9&nbsp;000</option>
        <option value="10000">R 10&nbsp;000</option>
        <option value="11000">R 11&nbsp;000</option>
        <option value="12000">R 12&nbsp;000</option>
        <option value="13000">R 13&nbsp;000</option>
        <option value="14000">R 14&nbsp;000</option>
        <option value="15000">R 15&nbsp;000</option>
        <option value="16000">R 16&nbsp;000</option>
        <option value="17000">R 17&nbsp;000</option>
        <option value="18000">R 18&nbsp;000</option>
        <option value="19000">R 19&nbsp;000</option>
        <option value="20000">R 20&nbsp;000</option>
        <option value="25000">R 25&nbsp;000</option>
        <option value="30000">R 30&nbsp;000</option>
        <option value="35000">R 35&nbsp;000</option>
        <option value="40000">R 40&nbsp;000</option>
        <option value="50000">R 50&nbsp;000</option>
        <option value="60000">R 60&nbsp;000</option>
        <option value="70000">R 70&nbsp;000</option>
        <option value="80000">R 80&nbsp;000</option>
        <option value="90000">R 80&nbsp;000 +</option>
      </select>
    </div>
  </div>
  <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3">
    <div class="form-group">
    <label style="color:#ea621e">Beds</label>
      <select required="required" name="beds" class="form-control form-control-lg ui-select" >
        <option value="0"  selected="selected">Any</option>
        <option value="1">1+</option>
        <option value="2">2+</option>
        <option value="3">3+</option>
        <option value="4">4+</option>
        <option value="5">5+</option>
        <option value="6">6+</option>
        <option value="7">7+</option>
      </select>
    </div>
  </div>
  <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3">
    <div class="form-group">
       <label style="color:#ea621e">Property Type</label>
      <select required="required" name="property_type" class="form-control form-control-lg ui-select" >
        <option value="0"  selected="selected">Any</option>
          <?php
            require_once('MysqliDb.php');$db11 = new MysqliDb ('rent');$result1=$db11->get('property_type');if(!empty($result1)){foreach ($result1 as $key1 => $value1) {echo '<option value="'.$value1["type_id"].'">'.$value1["type_description"].'</option>';}}
          ?> 
      </select>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-6 col-md-6  col-lg-6 col-xl-6">
    <div class="form-group">
      <button type="submit" class="btn btn-lg btn-primary btn-block">Search</button>
    </div>
  </div>
</div>

          </div>
  
    </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<div id="content" class="pt0 pb0">

  <div class="feature-box centered gray">
    <div>
      <div class="container">
        <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
            <div class="item-listing grid">
            <div class="main-title" style="color:#ea621e"><span>Featured Properties</span></div>
              
              <?php
              require_once('MysqliDb.php');
              
              $db1100 = new MysqliDb ('rent');
              $result100=$db1100->rawQuery("select user_id from users where user_type_id='2'");
              echo $result100;
			        if(!empty($result100)){$landlords_id=[];foreach($result100 as $key100 => $value100){$id = $value100['user_id'];$landlords_id[] = $id;}$landlords_id = implode(',',$landlords_id);} 
              $db11 = new MysqliDb ('rent');
              $result1=$db11->rawQuery("SELECT * FROM property where user_id in ($landlords_id) ORDER BY prop_id DESC LIMIT 3");
              if(!empty($result1)){
                foreach ($result1 as $key1 => $value1) {$image_name    =$value1['prop_main'];$price         =$value1['prop_price']; $title         =$value1['prop_title'];$loc  
				=$value1['prop_loc'];$bed           =$value1['prop_bed'];$bath          =$value1['prop_bath'];$prop_id       =$value1['prop_id'];$date=$value1['date'];$user_id       =$value1['user_id']; $main_path = 'agents/'.$user_id.'/property/'.$prop_id.'/main/'.$image_name;
              ?>
              <div class="col-md-4">
                  <div class="item">
                    <div class="item-image"><a href="property_single.php?id=<?php echo $prop_id; ?>"><img  src="<?php echo $main_path; ?>" class="img-fluid img-responsive" alt="">
                      <div class="item-badges">
                        <div class="item-badge-left">Available</div>
                        <!-- <div class="item-badge-right">For Sale</div> -->
                      </div>
                      </a> <!-- <a href="#" class="save-item"><i class="fa fa-star"></i></a> --> </div>
                    <div class="item-info">
                      <h3 class="item-title"><?php echo $title; ?></h3>
                      <div class="item-location"><i class="fa fa-map-marker"></i> <?php echo $loc; ?></div>
                      <div class="item-details-i">
                        <span class="bedrooms" data-toggle="tooltip" title="<?php echo 'R '.$price; ?>"><?php echo 'R '.$price; ?></span>&nbsp;
                        <span class="bedrooms" data-toggle="tooltip" title="<?php echo $bed; ?> Bedrooms"><?php echo $bed; ?> <i class="fa fa-bed"></i></span>&nbsp;
                        <span class="bathrooms" data-toggle="tooltip" title="<?php echo $bath; ?> Bathrooms"><?php echo $bath; ?> <i class="fa fa-bath"></i></span>
                      </div>
                    </div>
                  </div>
                </div>
              <?php
                }}
              ?>
           
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
 
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
</body>
</html>