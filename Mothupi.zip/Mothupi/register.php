<?php
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']!=''){
        header('Location:index.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<script>
var error_='Error with yor input';
function show_error(){

  $('#txt').empty();
  $('#txt').append(error_);
 
  $('#myModal').modal('show');
}
$( document ).ready(function() {
   
    $('#register').on('submit', function (e) {

        e.preventDefault();
      
        var form_data= $('#register').serialize();
        $.ajax({
            type: 'post',
            url: 'json.php?type=register',
            data: form_data,
            success: function (response) {
                
                if(response=='1'){
                    window.location.href="success.php?from=register";
                    
                }else{
                    
                    if(response=='2'){
                       
                        show_error('Emails do not match.');
                        error_='Emails do not match';
                    }
                    if(response=='3'){
                       
                        show_error();
                        error_='Passwords do not match.';
                        
                    }
                    if(response=='4'){
                       
                        show_error();
                        error_='You need to specify your account type';
                        
                    }
                    if(response=='5'){
                       
                        show_error();
                        error_='All fields are required';
                        
                    }
                    if(response=='6'){
                       
                      show_error();
                        error_='Email aready has an account';
                        //element.setCustomValidity('Email aready has an account') 
                    }
                    if(response=='0'){
                        window.location.href="404_error.php?from=register";
                     }
                }
                 }
      });
    });
});
</script>
<body>
<div id="main">
<?php include('navbar.php'); ?>
<div id="content" class="property-single">
    
  <div class="container">
        <div class="page-header"> <h1 style="color:#ea621e">Register / sign in</h1> </div>
        
        <div id="myModal" class="modal fade" role="dialog">
          <div class="modal-dialog">
        
            <!-- Modal content-->
            <div class="modal-content">
              
              <div class="modal-body">
                <p id="txt" style="font-weight:bold"></p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">OK</button>
              </div>
            </div>
        
          </div>
        </div>


    
    <form id="register">
       
      <div class="row col-sm-12 col-md-12 col-lg-12 col-xl-12">  
        <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="name" id="name" name="name"  required="required" class="form-control cv form-control-lg" placeholder="name">
          </div>
        </div>

        <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
          <div class="form-group">
          <label for="name">Surname</label>
            <input type="surname" id="sname" name="surname"  required="required" class="form-control cv form-control-lg" placeholder="surname">
          </div>
        </div>
      </div>

      <div class="row col-sm-12 col-md-12 col-lg-12 col-xl-12"> 
        <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
          <div class="form-group">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email"  required="required" class="form-control cv form-control-lg" placeholder="Email">
        </div>
        </div>

        <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
           <div class="form-group">
            <label for="cemail">Confirm Email address</label>
            <input type="email" id="cemail" name="cemail"  required="required" class="form-control cv form-control-lg" placeholder="Confirm Email">
          </div> 
        </div>
      </div>

      <div class="row col-sm-12 col-md-12 col-lg-12 col-xl-12"> 
        <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password"  required="required" class="form-control cv form-control-lg" placeholder="Password">
          </div>
        </div>

        <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
          <div class="form-group">
        <label for="cpassword">Confirm Password</label>
        <input type="password" id="cpassword" name="cpassword"  required="required" class="form-control cv form-control-lg" placeholder="Confim Password">
      </div>
        </div>
      </div>
      
        <div class="form-group">
          <label class="col-md-4 control-label" for="radios">Register as</label>
          <div class="col-md-4"> 
            <label class="radio-inline" for="radios-0">
              <input type="radio" required="required"  class="cv" name="radios" id="radios-0" value="1" checked="checked">
              Tenant
            </label> 
            <label class="radio-inline" for="radios-1">
              <input type="radio" required="required" class="cv" name="radios" id="radios-1" value="2">
              Landlord
            </label> 
            
          </div>
        </div>

      <p class="text-lg-left"><a href="signin.php">Already have an account</a></p>
      <button type="submit" class="btn btn-primary btn-lg">Register</button>
    </form>
  </div>
</div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>

</body></html>