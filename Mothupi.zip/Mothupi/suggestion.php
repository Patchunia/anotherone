<?php
session_start();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>
var use_id='<?php echo $_SESSION['user_id']; ?>';
$( document ).ready(function() {

    
    $('#suggestion_form').on('submit', function (e) {

        e.preventDefault();
        var form_data= $('#suggestion_form').serialize();
       
        $.ajax({
            type: 'post',
            url: 'json.php?type=suggestion',
            data: form_data,
            success: function (response) {
                if(response=='1'){
                    window.location.href="success.php?from=suggestion";
                }else{
                     window.location.href="404_error.php?from=suggestion";
                }
                
            }
      });
    });
      
    $('#m').css({"background-color":"#ea621e","border-color":"#ea621e","color":"white"});
    $('#c').css({"background-color":"#626262","border-color":"#626262","color":"white"});
    
     if(use_id>0){
       $('.list_suggestion').hide();
       $('.make-suggestion').show();
       
       $('#contact_name').attr('readonly', true);
       $('#contact_name').prop('readonly', true);
       $('#contact_email').attr('readonly', true);
       $('#contact_email').prop('readonly', true);
       
       $('#contact_name').val('<?php echo $_SESSION['user_name']?>');
       $('#contact_email').val('<?php echo $_SESSION['user_email']?>');
       
    }else{
        $('.list_suggestion').show();
        
    }
    
});



function show_(id){

    if(id=='m'){
        $('#m').css({"background-color":"#ea621e","border-color":"#ea621e","color":"white"});
         $('#c').css({"background-color":"#626262","border-color":"#626262","color":"white"});
        $('.list_suggestion').hide();
        $('.make-suggestion').show();
    }else{
         $('#m').css({"background-color":"#626262","border-color":"#626262","color":"white"});
        $('#c').css({"background-color":"#ea621e","border-color":"#ea621e","color":"white"});
        $('.list_suggestion').show();
        $('.make-suggestion').hide();
    }
}
</script>
<body>
   
<div id="main">
<?php include('navbar.php'); ?>
<div id="content" class="property-single">
  <div class="container">
      
      <?php if(isset($_SESSION['user_id'])){ ?>
       <div class="row col-sm-12 col-md-12 col-lg-12 col-xl-12">
            
                <!--<div class="col-sm-5 col-md-5 col-lg-5 col-xl-5">-->
                <!--    <button id="m" onclick="show_('m')" class="btn btn-block"> Make a suggestion</button>-->
                <!--</div>-->
                <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                </div>
                <!--  <div class="col-sm-5 col-md-5 col-lg-5 col-xl-5">-->
                <!--    <button id="c" onclick="show_('c')" class="btn btn-block"> See suggestions</button>-->
                <!--</div>-->
             
        </div>
        <?php } ?>
        <br>
        
        <?php
            require_once('MysqliDb.php');
            $db = new MysqliDb ('rentzywp_rentzar');
            $result=$db->get("suggestions");
            if(!empty($result)){
                foreach($result as $key => $value){
                    $user_id = $value['user_id'];
                    $date    = $value['date'];
                    $message = $value['message'];
                    
                    $db1 = new MysqliDb ('rentzywp_rentzar');
                    $db1->where("user_id='$user_id'");
                    $pe = $db1->get('users');
                    if(!empty($pe)){
                        foreach($pe as $key=>$value){
                            $user = $value['user_name'];
                        }
                    }
                    
                   // echo '<div class="row col-sm-12 col-md-12 col-lg-12 col-xl-12 list_suggestion">';
                   // echo '<div class="col-sm-12 col-md-3 col-lg-3 col-xl-3">';
                       // echo '<b>'.$user.'</b><br>'.$date;
                    //echo '</div>';
                   
                   // echo '<div class="col-sm-12 col-md-9 col-lg-9 col-xl-9">';
                      // echo $message;
                   // echo '</div>';
                    
                //echo '</div><hr class="list_suggestion">';
                }
                
            }else{
                //echo 'No suggestions posted as yet';
            }
        ?>
            
            
        <?php// if(isset($_SESSION['user_id'])){ ?>
        <center><h2 style="color:#ea621e">Send us your suggestions</h2></center>
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 make-suggestion">
            <div class="card">
              <form id="suggestion_form">
                <div class="form-group">
                  <label for="contact_name">Your Name</label>
                  <input required="required" type="text" class="form-control" id="contact_name" name="contact_name" placeholder="Your Name">
                </div>
                <div class="form-group">
                  <label for="contact_email">Your Email</label>
                  <input required="required"  type="email" class="form-control" id="contact_email" name="contact_email" placeholder="Your Email">
                </div>
                
                <div class="form-group">
                  <label for="contact_message">Message</label>
                  <textarea required="required"  rows="4" class="form-control" id="contact_message" name="contact_message" placeholder="Message"></textarea>
                </div>
                <button type="submit" class="btn btn-lg btn-primary">Send Message</button>
              </form>
            </div>
          </div>
        
        <?php// } ?>
      
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>

</body></html>