<footer id="footer">
  <div class="container">
     
        <div class="col col-md-12">
        <div class="row"> 
          <div class="col-md-4  col-sm-12">
            <h4>Our Company</h4>
            <ul class="list-unstyled">
              <li><a href="information_page.php">About</a></li>
              <li><a href="terms.php">Terms and conditions</a></li>
            </ul>
          </div> 
          <div class="col-md-4 col-sm-12">
          <h4>Work With Us</h4>
            <ul class="list-unstyled">
              <li><a href="contact.php">Contact us</a></li>
              <li><a href="suggestion.php">Give a Suggestion</a></li>
              <li><a href="https://www.facebook.com/RentZAR/">Facebook</a></li>
              <li><a href="https://www.instagram.com/rentzar8900/">Instagram</a></li>
            </ul>
          </div>
          <div class="col-md-4 col-sm-12">
          <h4>Customer Support</h4>
            <ul class="list-unstyled">
              <li><a href="contact.php">info@rentzar.co.za</a></li>
              <li><a href="contact.php?t=f">Feedback</a></li>
            </ul>
          
          </div>
        </div>
      </div>
      
      <br><center><b></b><p style="color:#ea621e;">RENTZAR All rights reserved © <?php echo date('Y'); ?></p></b></center>
     
  </div>
</footer>