<?php
if(isset($_REQUEST['hash'])){
    $reset=$_REQUEST['hash'];
    require_once('MysqliDb.php');
    $db = new MysqliDb ('rentzywp_rentzar');
    $db->where("user_reset='$reset'");
    $db->where("account_status='1'");
    $result = $db->get('users');
    if(!empty($result)){
        foreach($result as $key => $value){
            $user_id = $value['user_id'];
            $date = $value['reset_date'];
        }
    }else{
        exit();
    }
}else{
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>
$( document ).ready(function() {
    $('#password_id').hide();
    $('#resetit').on('submit', function (e) {
        
        e.preventDefault();
        var form_data= $('#resetit').serialize();
        $.ajax({
            type: 'post',
            url: 'json.php?type=reset',
            data: form_data,
            success: function (response) {
                if(response=='1'){
                    window.location.href="success.php?from=reset";
                }else{
                     window.location.href="404_error.php?from=reset";
                }
            }
      });
    });
});
</script>
<body>
<div id="main">
    <br><br>
<div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-md-8  col-lg-6">
         
        <div class="page-header">
        <h1 style="color:#ea621e">RentZAR Reset Password</h1>
        </div>
      </div>
    </div>
  </div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
        
       <?php
           $current_time = date('Y-m-d H:i:s');
            $current_time = strtotime($current_time);
    		$initial_request_time = strtotime($date);
    		$difference_in_minutes = round(abs($current_time - $initial_request_time) / 60,2);
    
    		if($difference_in_minutes >= 60){
    		    echo '<div>This reset link has expired! </div>&nbsp;';
                echo '<br>';
                echo '<div>Visit <a style="color:#ea621e" href="www.lets-snap.co.za/rentzar_rentzar222">RentZAr</a> to create a new account or sign in</div>';
            
                exit();
    		}
        ?>
      <div class="col col-md-8  col-lg-6">
      <p>Please reset your password below.</p>
            <form id="resetit">
            <div class="form-group">
            <label for="email">New Password</label>
            <input type="password" required="required" name="password" id="password" class="form-control input-lg">
          </div>
          
          <div class="form-group">
            <input type="text" required="required" name="password_id" id="password_id" class="form-control input-lg" value="<?php echo $user_id;?>">
          </div>
         
          
              <button type="submit" class="btn btn-primary btn-lg">Continue</button>
            </form>
        
        
        <div> </div>
      </div>
    </div>
  </div>
</div>
</div>

</body></html>