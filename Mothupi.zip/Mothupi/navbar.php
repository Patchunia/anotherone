<?php

if(isset($_SESSION['user_id'])){
    $user_name = substr($_SESSION['user_name'], 0, 6);
}else{
   $user_name=''; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>RentZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/swiper/css/swiper.min.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/swiper/js/swiper.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<script>
var menu_stat='0';

function set_it_(){
   
        menu_stat='0';
        $(".navbar-collapse").hide();

}

function check_menu(){
  
  if(menu_stat=='0'){
      menu_stat='1';
      $(".navbar-collapse").show();
  }else{
      set_it_();
  }
    
    
}

$( document ).ready(function() {  


});
  

</script>   
 

<style type="text/css">
  #menu {
    background-color: #ea621e !important;
  }

  .btn-primary, .btn-primary:focus, .btn-primary:hover, .btn-primary:active, .btn-primary:active:hover, .btn-primary:active:focus {
    background-color: #ea621e !important;
    border-color: #ea621e !important;
    color:white !important;
}

.item-listing .item .item-badges .item-badge-left {
    background-color: #ea621e !important;
    }

    .list-group.no-border .list-group-item.active, .list-group.no-border .list-group-item.active:focus, .list-group.no-border .list-group-item.active:hover {
    background-color: #ea621e !important;
    color:white !important;
  }

  a:focus, a:hover, a:active {
    color: #ea621e !important;
}

</style>

<nav class="navbar navbar-expand-lg navbar-dark" id="menu">
   
  <div class="container">
  <a class="navbar-brand" href="index.php"><h1><span style="color:white">RENT</span><span style="color:#41f4af">ZAR</span></h1></a>
  
  <button class="navbar-toggler"  id="myNavbar" onclick="check_menu();" type="button" data-toggle="collapse" data-target="#menu-content" aria-controls="menu-content" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div style="margin-right:200px"></div>
  <div class="collapse navbar-collapse" id="menu-content">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
          <?php if(isset($_SESSION['user_id']) && $_SESSION['user_type_id']=='2'){ ?>
          
        <a class="nav-link" onclick="window.location.href='index.php?landlord'" href="index.php?landlord" role="button" >
          Home <span class="sr-only">(current)</span>
        </a>
        <?php }
            if(!isset($_SESSION['user_id'])){ ?>
         <a class="nav-link" onclick="window.location.href='index.php'" href="index.php" role="button" >
          Home <span class="sr-only">(current)</span>
        </a>
        <?php } ?>
        
        <?php if(isset($_SESSION['user_id']) && $_SESSION['user_type_id']=='1' ){ ?>
         <a class="nav-link" onclick="window.location.href='index.php?tenant'" href="index.php?tenant" role="button" >
          Home <span class="sr-only">(current)</span>
        </a>
        <?php } ?>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link" onclick="window.location.href='landlord.php'" href="landlord.php" role="button" >
          Landlords
        </a>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link" onclick="window.location.href='tenant.php'" href="tenant.php" role="button" >
          Tenants
        </a>
      </li>

      <!--<li class="nav-item dropdown">-->
      <!--  <a class="nav-link" onclick="window.location.href='suggestion.php'" href="suggestion.php" role="button" >-->
      <!--    Suggestions-->
      <!--  </a>-->
      <!--</li>-->

       <li class="nav-item dropdown">
        <a class="nav-link" onclick="window.location.href='information_page.php'" href="information_page.php" role="button" >
          About 
        </a>
      </li>

      <!--<li class="nav-item dropdown">-->
      <!--  <a class="nav-link" onclick="window.location.href='contact.php'" href="contact.php" role="button" >-->
      <!--    Contacts  -->
      <!--  </a>-->
      <!--</li>-->
      
     

      <?php if(!isset($_SESSION['user_id'])){ ?>
      <li class="nav-item dropdown">
        <a class="nav-link" onclick="window.location.href='signin.php'" href="signin.php" role="button" >
          Login  
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link" onclick="window.location.href='register.php'" href="register.php" role="button" >
          Register 
        </a>
      </li>
     
    </ul>
    <?php }else{ ?>

    <ul class="navbar-nav mr-auto">
      
      <?php if($_SESSION['user_type_id']>'0'){ ?>

      <li class="nav-item dropdown">
        <a class="nav-link" href="my_profile.php" role="button" >
          Profile  <?php 
                    $n = substr($_SESSION['user_name'], 0, 6);
                  if(isset($_SESSION['user_id'])){
                      if($_SESSION['user_type_id']==1){
                          $user_type_name='Tenant';
                      }else{
                          $user_type_name='Landlord';
                      }
                      echo ucfirst($user_type_name).' - '.ucfirst($n.'..');
                      
                      
                  }
                  ?>
        </a>
      </li>

      <!--<li class="nav-item dropdown">
        <a class="nav-link" href="my_profile.php" role="button" >
          <?php// echo '<span class="fa fa-user"></span> '.$user_name; ?>
        </a>
      </li>-->
 
      <?php } ?>
      
    </ul>
    
         <li class="nav-item dropdown">
        <a href="logout.php" class="nav-link" role="button">Logout</a>
      </li>
    
    <?php } ?>
  </div>
  </div>
</nav>
<nav> 
 
<?php ob_end_flush();?>
