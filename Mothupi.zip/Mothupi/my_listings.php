<?php 
session_start();
if(!isset($_SESSION['user_name'])){
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/tinymce/tinymce.min.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<style>
    .remove-item{
        margin-left:10px;
        float: left;
    }
</style>

<script>
var list_id='';
    function delete_list(id){
        list_id=id;
        $('#myModal').modal('show');
    }
    function edit_list(id){
        list_id=id;
    }
    function delete_confirm(){
        
        $.ajax({
            type: 'post',
            url: 'json.php?type=delete_list&id='+list_id,
            data:'',
            success: function (response) {
                if(response=='1'){
                    window.location.href="my_listings.php";
                } 
            }
      });
    }
</script>

<body>
<div id="main">
<?php include('navbar.php'); ?>


 <!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p style="font-weight:bold">Are you sure you want to delete this listing ?</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-success" onclick="delete_confirm();" data-dismiss="modal">Yes</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
        </div>
      </div>
    </div>
  </div>
</div>



<div class="clearfix"></div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
          <div class="col col-lg-12 col-xl-10">
        <div class="row has-sidebar">
          <div class="col-md-5 col-lg-4 col-xl-4">
            <div id="sidebar" class="sidebar-left">
              <div class="sidebar_inner">
                <div class="list-group no-border list-unstyled">
                    
                <?php if($_SESSION['user_type_id']!='' && $_SESSION['user_type_id']==2){ ?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center active"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                   
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_profile_pic.php" class="list-group-item"><i class="fa fa-fw fa-user"></i> My Profile picture</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                    
                 <?php }else{?>
                    <span class="list-group-item heading">Manage Listings</span>
                    <a href="my_listing_add2.php" class="list-group-item"><i class="fa fa-fw fa-plus-square-o"></i> Add Listing</a>
            
                    <a href="my_listings.php" class="list-group-item d-flex justify-content-between align-items-center active"><span><i class="fa fa-fw fa-bars"></i> My Listings</span>
                    
                    </a>
                    
                    <span class="list-group-item heading">Manage Account</span>
                    <a href="my_profile.php" class="list-group-item"><i class="fa fa-fw fa-pencil"></i> My Profile</a>
                    <a href="my_password.php" class="list-group-item"><i class="fa fa-fw fa-lock"></i> Change Password</a>
                 <?php } ?>
                   
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-7 col-lg-8 col-xl-8">
            <div class="page-header bordered">
              <h1>My Listings</h1>
            </div>
            <div class="item-listing list">
                <?php
 
                  if($_SESSION['user_id']!='' && $_SESSION['user_type_id'] > '0'){
                    $user_id = $_SESSION['user_id'];
                    require_once('MysqliDb.php');
                    $db1 = new MysqliDb ('rentzywp_rentzar');
                    $db1-> where("user_id='$user_id'");
                    $result=$db1->get('property');
                    if(!empty($result)){
                      foreach ($result as $key => $value) {
                        $image_name    =$value['prop_main'];
                        $price         =$value['prop_price'];
                        $prop_id       =$value['prop_id'];
                        $title         =$value['prop_title'];
                        $loc           =$value['prop_loc'];
                        $bed           =$value['prop_bed'];
                        $bath          =$value['prop_bath'];
                        $date          =$value['date'];
                        $name          =$_SESSION['user_name'];

                        $main_image_path = 'agents/'.$user_id.'/property/'.$prop_id.'/main/'.$image_name;
                       
                        if (!file_exists($main_image_path)) {
                          $main_image_path = 'agents/stock_image.png';

                        }
                        
                        $main_image_path2 = 'agents/stock_image.png';

                        echo '<div class="item">';
                        echo '<div class="row">';
                          echo '<div class="col-lg-5">';
                            echo '<div class="item-image">';
                              echo '<a href="property_single.php?id='.$prop_id.'">';
                              if($_SESSION['user_type_id']>'1'){
                                  echo '<img src="'.$main_image_path.'" class="img-fluid" alt="">';
                              echo '</a>';
                              } 
                           echo '</div>';
                           
                            echo '<a href="#" class="remove-item" onclick="delete_list('.$prop_id.')" style="color:red">';
                              echo '<i class="fa fa-trash-o"></i> Delete ';
                            echo '</a>';
                            
                          echo '</div>';
                          echo '<div class="col-lg-7">';
                            echo '<div class="item-info">';
                              echo '<h3 class="item-title">';
                                echo '<a href="property_single.php?id='.$prop_id.'">'.$title.'</a>';
                              echo '</h3>';
                              echo '<div class="item-location">';
                                echo '<i class="fa fa-map-marker"></i> '.$loc.' ';
                              echo '</div>';
                              echo '<div class="item-details-i"> ';
                                echo '<span class="bedrooms" data-toggle="tooltip" title="'.$price.'">'.$price.'</span>&nbsp; ';
                                echo '<span class="bedrooms" data-toggle="tooltip" title="'.$bed.' bedroom(s)" >'.$bed.' <i class="fa fa-bed"></i></span> &nbsp; ';
                                echo '<span class="bathrooms" data-toggle="tooltip" title="'.$bath.' bathrooms(s)">'.$bath.' <i class="fa fa-bath"></i></span> ';
                              echo '</div>';
                            echo '</div>';
                            echo '<br>';
                            echo '<div class="row">';
                              echo '<div class="col-md-6">';
                                echo '<div class="added-on">Listed on '.$date.' ';
                                echo '</div>';
                              echo '</div>';
                              echo '<div class="col-md-6">';
                                echo '<a href="agent.php?id='.$user_id.'" class="added-by">by '.$name.'</a>';
                              echo '</div>';
                            echo '</div>';
                          echo '</div>';
                        echo '</div>';
                      echo '</div>';

                      }
                    }else{
                      echo '<h4>You have not added any listings as yet</h4>';
                    }
                  }

                ?>

            </div>
            <!--<nav aria-label="Page navigation">-->
            <!--  <ul class="pagination">-->
            <!--    <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>-->
            <!--    <li class="page-item active"><a class="page-link" href="#">1</a></li>-->
            <!--    <li class="page-item"><a class="page-link" href="#">2</a></li>-->
            <!--    <li class="page-item"><a class="page-link" href="#">3</a></li>-->
            <!--    <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>-->
            <!--  </ul>-->
            <!--</nav>-->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>  
</body>
</html>