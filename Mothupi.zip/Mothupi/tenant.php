<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/sidr/jquery.sidr.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<style>
    .item-listing .item { 
  
                box-shadow: 0px 2px 10px 5px #ea621e !important
    }
</style>
 
<body>
<div id="main">
<?php include('navbar.php'); ?>
 
<div class="container">
  <div class="row justify-content-md-center">
    <div class="col col-lg-12 col-xl-10">
     
      <div class="page-header">
        <h2 style="color:#ea621e">Potential tenants are looking for</h2>
      </div>
    </div>
  </div>
</div>
<div id="content">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-lg-12 col-xl-10">
        
            <div class="clearfix"></div>
            <div class="item-listing grid">
              <div class="row">
              <?php
             
              require_once('MysqliDb.php');
              
              $db1100 = new MysqliDb ('rentzywp_rentzar');
              $result100=$db1100->rawQuery("select user_id from users where user_type_id='1'");
              if(!empty($result100)){
                  $landlords_id=[];
                  foreach($result100 as $key100 => $value100){
                      $id = $value100['user_id'];
                      $landlords_id[] = $id;
                  }
                  
                  $landlords_id = implode(',',$landlords_id);
              }else{
                  echo '<h4>No search results found </h4>';
              }
                
                $db1 = new MysqliDb ('rentzywp_rentzar');
                 
                $result=$db1->rawQuery("select * from property where user_id in ($landlords_id) order by prop_id desc");
          
                if(!empty($result)){
                  foreach ($result as $key => $value) {
                    $image_name    =$value['prop_main'];
                    $price         =$value['prop_price'];
                    $prop_id       =$value['prop_id'];
                    $title         =$value['prop_title'];
                    $loc           =$value['prop_loc'];
                    $bed           =$value['prop_bed'];
                    $bath          =$value['prop_bath'];
                    $user_id       =$value['user_id'];
                    $desc       =$value['prop_desc'];
                    //$water       =$value['prop_water_include'];
                    //$elec      =$value['prop_elec_include'];
                    $prop_type = $value['property_type'];
                    
                    
                    $db11 = new MysqliDb ('rentzywp_rentzar');
                    $db11->where("type_id='$prop_type'");
                   
                    $result1=$db11->get('property_type');
                    if(!empty($result1)){
                    foreach ($result1 as $key1 => $value1) {
                      $property_t = $value1['type_description'];
                    }
                    }else{
                        $property_t = 'Any';
                    }

                    $main_image_path = 'agents/stock_image.png';
                    
                    // if($water=='1'){
                    //     $water ='included';
                    // }else{
                    //     $water ='not included';
                    // }
                    
                    // if($elec=='1'){
                    //     $elec ='included';
                    // }else{
                    //     $elec ='not included';
                    // }
                   
                     ?>
                  <div class="col-lg-6">
                    <div class="item">
                         
                      <div class="item-info">
                          <a href="property_single.php?id=<?php echo $prop_id; ?>">
                        <h3 class="item-title"><?php echo $property_t.' - '.$title; ?></h3>
                        <div class="item-location"><i class="fa fa-map-marker"></i> <?php echo $loc; ?></div>
                        <div class="item-details-i"> <span class="bedrooms" data-toggle="tooltip" title="<?php echo 'R '.$price; ?>"><?php echo 'R '.$price; ?></span>&nbsp; <span class="bedrooms" data-toggle="tooltip" title="<?php echo $bed; ?> Bedroom(s)"><?php echo $bed; ?><i class="fa fa-bed"></i></span>&nbsp; <span class="bathrooms" data-toggle="tooltip" title="<?php echo $bath; ?> Bathroom(s)"><?php echo $bath; ?> <i class="fa fa-bath"></i></span> 
                        <!-- <div class="item-location"><?php// echo 'Water '.$water; ?></div>
                        <div class="item-location"><?php// echo 'Electricity '.$elec; ?></div> -->
                        <div class="item-location"><?php echo $desc ?></div>
                        <div class="item-location"><button class="btn btn-sm btn-primary">View more</button></div>
                        
                        </div>
                        </a>
                      </div>
                    </div>
                  </div>                    
            <?php }
                  
              }else{
                  
                      echo '<h4>No search results found for <div style="color:#ea621e"> "'.$address.'"</div></h4>';
              }
              ?>



              </div>
             
            </div>
            
          </div>
        </div>  
      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>
<script>
R(document).ready(function() {
  R('#toggle-filters').sidr({
    side: 'left',
    displace : false,
    renaming : false,
    name: 'sidebar',
    source: function() {
      AOS.refresh();
    },
    
  });
});
</script>
</body>
</html>