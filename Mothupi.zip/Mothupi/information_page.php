<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Rent ZAR</title>

<!-- Bootstrap -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900%7COpen+Sans" rel="stylesheet" />
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="lib/animate.css" rel="stylesheet">
<link href="lib/selectric/selectric.css" rel="stylesheet">
<link href="lib/aos/aos.css" rel="stylesheet">
<link href="lib/Magnific-Popup/magnific-popup.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="lib/jquery-3.2.1.min.js"></script>
<script src="lib/popper.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="lib/selectric/jquery.selectric.js"></script>
<script src="lib/aos/aos.js"></script>
<script src="lib/Magnific-Popup/jquery.magnific-popup.min.js"></script>
<script src="lib/sticky-sidebar/ResizeSensor.min.js"></script>
<script src="lib/sticky-sidebar/theia-sticky-sidebar.min.js"></script>
<script src="lib/lib.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<style>
    .title{
        color:#ea621e;
    }
</style>
<body>
<div id="main">
<?php include('navbar.php'); ?>
<div id="content" class="property-single">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-lg-12 col-xl-8">
       <!--  <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
            </ol>
            </nav> -->
        <div class="page-header v2 bordered">
        <h1 style="color:#ea621e">About Us <small>Know us</small></h1>
        </div>
        <h4 class="title">Who we are?</h4>
        <p>RENTZAR is a free property listing rental website which connects Landlords and tenants together with the purpose of providing rental accommodation.
This web platform is for individuals of all types ranging from young professionals, students, or families, and provides the option to share a room if permitted by the property owner to minimise rental expenses. 
This site allows listing across all provinces, cities and townships in South Africa
  </p>

        <h4 class="title">Why us?</h4>
        <p>We provide you with a new, convenient way of finding your ideal apartment to rent, or obtain your ideal tenants for your accommodation, all on one online platform.
This saves you time from traditional methods of going to retail stores to search on notice boards, or needless costs in print ads to place on notice boards and street lights
</p>
        
        <h4 class="title">Who are the people behind the company?</h4>
        <p>The company was founded in 2017 by ML Nkadimeng after he noticed how people had challenges in finding their perfect tenants or landlords for rental accommodation.
It was after noticing the frustration & time it took individuals to search in retail stores, on city and town street lights & walls, that he decided he’d create a convenient web platform for anyone to use to quickly & easily find their dream accommodation.
</p>

      </div>
    </div>
  </div>
</div>
<button class="btn btn-primary btn-circle" id="to-top"><i class="fa fa-angle-up"></i></button>
<?php include('footer.php'); ?>
</div>

</body></html>