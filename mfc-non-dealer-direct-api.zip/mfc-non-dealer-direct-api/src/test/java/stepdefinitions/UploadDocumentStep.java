package stepdefinitions;

import GlobalFunctions.Global;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class UploadDocumentStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global global_functions;
    public UploadDocumentStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        global_functions = new Global();
    }

    @Given("^that i am buying vehicle from a dealer$")
    public void that_i_am_buying_vehicle_from_a_dealer() {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I submit  \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_submit_and(String fileName,String appRef,String fileType, String fileFormat){
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.saveDocuments(fileName, appRef,fileType, fileFormat);
    }

    @Then("^the uploading of documents result should return \"([^\"]*)\"$")
    public void the_uploading_of_documents_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.validateDocUpload(result);
    }


}
