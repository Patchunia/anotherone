package stepdefinitions;

import GlobalFunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class FinanceAmountDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    ReadCSV test;
    List<String[]> lines;
    public FinanceAmountDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("InstalmentDetailsData.csv");
    }
    public void DataDrive()
    {
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            createRecordTest.saveInstallmentDetails(
                    Integer.parseInt(lineContents[0]), lineContents[1],
                    Integer.parseInt(lineContents[2]),
                    Integer.parseInt(lineContents[3]), Boolean.parseBoolean(lineContents[4]),
                    lineContents[5], Integer.parseInt(lineContents[5]), Integer.parseInt(lineContents[6]),
                    Integer.parseInt(lineContents[7]), Boolean.parseBoolean(lineContents[8]));
        }
    }
    @Given("^that I have a set of \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_and(int  IDNumber, String PurchasePrice,int Deposit,int BalloonPayment,
                                         boolean balloonPaymentOption,String firstPayment, int term,
                                         int interestRate,int estimatedMonthlyInstalment, boolean dealerType) {
        // Write code here that turns the phrase above into concrete actions
       createRecordTest.saveInstallmentDetails(IDNumber,PurchasePrice,Deposit,BalloonPayment,balloonPaymentOption,
               firstPayment,term,interestRate,estimatedMonthlyInstalment,dealerType);

        //DataDrive();
    }


    @When("^I submit vehicle installments details to the system$")
    public void i_submit_vehicle_installments_details_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of vehicle installments result should return \"([^\"]*)\"$")
    public void the_capturing_of_vehicle_installments_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
       createRecordTest.shouldGet200Response(result);
    }

    @Given("^that I have a set of changed  \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_and(int  IDNumber, String PurchasePrice,int Deposit,int BalloonPayment,
                                                 boolean balloonPaymentOption,String firstPayment, int term,
                                                 int interestRate,int estimatedMonthlyInstalment, boolean dealerType) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveInstallmentDetails(IDNumber,PurchasePrice,Deposit,BalloonPayment,balloonPaymentOption,
                firstPayment,term,interestRate,estimatedMonthlyInstalment,dealerType);
        //DataDrive();
    }

    @Then("^the updating of vehicle installments result should return \"([^\"]*)\"$")
    public void the_updating_of_vehicle_installments_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }

    @When("^user submits request to view lookups$")
    public void user_submits_request_to_view_lookups() {
        // Write code here that turns the phrase above into concrete actions
        getRecordTest.callGetInstallmentAPI();
    }

    @Then("^installment lookups must be loaded$")
    public void installment_lookups_must_be_loaded() {
        // Write code here that turns the phrase above into concrete actions

    }
}
