package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.awt.event.FocusAdapter;

public class SubmitToFoxStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    public SubmitToFoxStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
    }
    @Given("^that I have a set of submission details \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_submission_details_and(String dashboardID, String foxReference) {
        createRecordTest.saveSubmissionToFox(dashboardID,foxReference);
    }

    @When("^I submit submission details to the system$")
    public void i_submit_submission_details_to_the_system(){
        // Write code here that turns the phrase above into concrete actions

    }
    @Then("^the submission result should return \"([^\"]*)\" and \"([^\"]*)\"$")
    public void the_submission_result_should_return_and(String FoxRef, String Description)  {
        // Write code here that turns the phrase above into concrete actions

    }
    @Then("^the submission result should return \"([^\"]*)\"$")
    public void the_submission_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }

    @Given("^that I have a set of updated details \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_updated_details_and(String DashboardID, String FoxReference)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveSubmissionToFox(DashboardID, FoxReference);
    }

    @Then("^the update of submission result should return \"([^\"]*)\"$")
    public void the_update_of_submission_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }



}
