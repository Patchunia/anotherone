package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class PersonallIncomeDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public PersonallIncomeDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();

    }
    @Given("^that I have a set of personal income details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void that_I_have_a_set_of_personal_income_details(int IDNumber, int EarningBeforeDeduction,int EarningAfterDeduction,int MonthlyExpenses){
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.savePersonalIncome(IDNumber,EarningBeforeDeduction,EarningAfterDeduction,MonthlyExpenses);
    }

    @Given("^that I have a set of changed personal income details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_personal_income_details(int IDNumber, int EarningBeforeDeduction,int EarningAfterDeduction,int MonthlyExpenses) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.savePersonalIncome(IDNumber,EarningBeforeDeduction,EarningAfterDeduction,MonthlyExpenses);
    }


    @When("^I submit personal income details to the system$")
    public void i_submit_personal_income_details_to_the_system(){
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of personal income details result should return \"([^\"]*)\"$")
    public void the_capturing_of_personal_income_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }



}
