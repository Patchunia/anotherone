package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class SellerDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public SellerDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();

    }
    @Given("^that I have a set of seller details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"  and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_seller_details_and(int IDNumber,String FirstName,String Surname,String CellPhone,String EmailAddress){
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveSellerDetails(IDNumber,FirstName,Surname,CellPhone,EmailAddress);
    }
    @Given("^that I have a set of  changed seller details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_seller_details_and(int IDNumber,String FirstName,String Surname,String CellPhone,String EmailAddress) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveSellerDetails(IDNumber,FirstName,Surname,CellPhone,EmailAddress);
    }
    @When("^I submit seller details to the system$")
    public void i_submit_seller_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions
    }

    @Then("^the capturing of seller details result should return \"([^\"]*)\"$")
    public void the_capturing_of_seller_details_result_should_return(String result){
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }

    @Then("^the updating of seller details result should return \"([^\"]*)\"$")
    public void the_updating_of_seller_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }
}
