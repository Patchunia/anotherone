package stepdefinitions;
import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class PersonalDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public PersonalDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();

    }
    @When("^I submit personal details to the system$")
    public void i_submit_personal_details_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }



    @Given("^that I have a set of personal details \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_personal_details_and(int IdentityNumber, String Title , String FirstName, String Surname ,
                                                          String MaritalStatus, String WorkTelephone, String HomeTelephone,
                                                          String EmailAddress,String AdditionalNationality, String Nationality
            , String Citizenship , String EthnicGroup, boolean MultipleNationality, boolean ForeignTaxObligation)
    {
       createRecordTest.savePersonalDetails(IdentityNumber,Title,FirstName,Surname,MaritalStatus,WorkTelephone,HomeTelephone, EmailAddress,
               AdditionalNationality,Nationality,Citizenship,EthnicGroup,MultipleNationality,ForeignTaxObligation);
    }


    @Given("^that I have a set of changed personal details \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_personal_details_and(int IdentityNumber, String Title , String FirstName, String Surname ,
                                                                  String MaritalStatus, String WorkTelephone, String HomeTelephone,
                                                                  String EmailAddress,String AdditionalNationality, String Nationality
            , String Citizenship , String EthnicGroup, boolean MultipleNationality, boolean ForeignTaxObligation) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.savePersonalDetails(IdentityNumber,Title,FirstName,Surname,MaritalStatus,WorkTelephone,HomeTelephone, EmailAddress,
                AdditionalNationality,Nationality,Citizenship,EthnicGroup,MultipleNationality,ForeignTaxObligation);
    }


    @Then("^the capturing of personal details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successful_captured(String compareString)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(compareString);
    }

    @Then("^the updating of personal details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successful_updated(String compareString)  {
        createRecordTest.shouldGet200Response(compareString);
    }



}
