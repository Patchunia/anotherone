package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class ResidentialAddressDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public ResidentialAddressDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();

    }
    @Given("^that I have a set of residential address details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void that_I_have_a_set_of_residential_address_details(int IdentityNumber, String PhysicalAddress,boolean MailAddressConfirmation ,String ResidentialStatus, String CurrentAddressDate,
                                                                 String PostalAddressLine1, String PostalAddressLine2,
                                                                 String Suburb, String City, String PostCode){
        createRecordTest.saveResidentialAddress(IdentityNumber,PhysicalAddress,MailAddressConfirmation,
                ResidentialStatus,CurrentAddressDate,PostalAddressLine1,PostalAddressLine2,Suburb,City,PostCode);

    }


    @Given("^that I have a set of changed residential address details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_residential_address_details(int IdentityNumber, String PhysicalAddress,boolean MailAddressConfirmation ,String ResidentialStatus, String CurrentAddressDate,
                                                                         String PostalAddressLine1, String PostalAddressLine2,
                                                                         String Suburb, String City, String PostCode)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveResidentialAddress(IdentityNumber,PhysicalAddress,MailAddressConfirmation,
                ResidentialStatus,CurrentAddressDate,PostalAddressLine1,PostalAddressLine2,Suburb,City,PostCode);
    }
    @When("^I submit residential address details to the system$")
    public void i_submit_residential_address_details_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of residential address details result should return \"([^\"]*)\"$")
    public void the_capturing_of_residential_address_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }

    @Then("^the updating of residential address details result should return \"([^\"]*)\"$")
    public void the_updating_of_residential_address_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }

}
