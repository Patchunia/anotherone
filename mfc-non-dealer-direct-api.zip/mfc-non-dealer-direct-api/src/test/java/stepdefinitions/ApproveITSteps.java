package stepdefinitions;

import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.runtime.java.StepDefAnnotation;

import net.thucydides.junit.annotations.UseTestDataFrom;

import org.junit.Test;
import services.ApproveITTests;



public class ApproveITSteps {

    ApproveITTests approveITTests ;

    public ApproveITSteps() {
       this.approveITTests = new ApproveITTests();
    }

    @Given("^user sends \"([^\"]*)\" and \"([^\"]*)\" to InitiateUSSD$")
    public void user_sends_and_to_InitiateUSSD(String IDNumber, String Cellphone)  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendRequest("InitiateUSSD",IDNumber,Cellphone);
    }


    @When("^when i get a successful response and verification ID$")
    public void when_i_get_a_successful_response_and_verification_ID()  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.validateInitiateResponse();
    }

    @When("^sending verificationID$")
    public void sending_verificationID() {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendVerificationID("VerifyUSSDpoll", "");
    }

    @Then("^sending and verification of OTP should return \"([^\"]*)\"$")
    public void sending_and_verification_of_OTP_should_return(int result) {
        // Write code here that turns the phrase above into concrete actions
       approveITTests.shouldGetResponse(result);
    }

    @Given("^user sends \"([^\"]*)\" and \"([^\"]*)\" to InitiateOTP$")
    public void user_sends_and_to_InitiateOTP(String IDNumber, String Cellphone)  {
        // Write code here that turns the phrase above into concrete actions
       approveITTests.sendRequest("InitiateOTP", IDNumber,Cellphone);
    }

    @When("^when i get a successful response and verification ID and OTP$")
    public void when_i_get_a_successful_response_and_verification_ID_and_OTP()  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.validateInitiateResponse();
    }

    @When("^sending verificationID and OTP$")
    public void sending_verificationID_and_OTP() {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendVerificationID("VerifyOTP","370800");
    }



}