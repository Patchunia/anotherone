package stepdefinitions;

import GlobalFunctions.DataDrivenTests;
import GlobalFunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;

public class MonthlyExpensesStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    ReadCSV test;
    List<String[]> lines;
    public MonthlyExpensesStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("MonthlyExpensesData.csv");
    }
     public void DataDrive()
     {
         for (int i = 0; i < lines.size(); i++) {
             String[] lineContents = lines.get(i);
             createRecordTest.saveMonthlyExpenses(
                     Integer.parseInt(lineContents[0]), lineContents[1],
                     Integer.parseInt(lineContents[2]),
                     lineContents[3],lineContents[4], lineContents[5],
                     lineContents[6], lineContents[7], lineContents[8], lineContents[9],
                     lineContents[10], lineContents[11],
                     lineContents[12], lineContents[13], lineContents[13]);
         }
     }
    @Given("^that I have a set of monthly expense details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" , \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_monthly_expense_details_and(int dashboardID, String identityNumber,int netSalary,String loanOrRentAmount,
                                                                 String utilities, String foodAndHouseholdExpenses,String transportation,
                                                                 String policiesAndInsurance,String clothing,String entertainment,
                                                                 String education,String savings, String phone, String creditCardPayments, String creditCardAmount) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveMonthlyExpenses(dashboardID,identityNumber,netSalary,loanOrRentAmount,utilities,foodAndHouseholdExpenses,
                transportation,policiesAndInsurance,clothing,entertainment,education,savings,phone,creditCardPayments,creditCardAmount);
        //DataDrive();

    }


    @Given("^that I have a set of updated monthly expense details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" , \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_updated_monthly_expense_details_and(int dashboardID, String identityNumber,int netSalary,String loanOrRentAmount,
                                                                         String utilities, String foodAndHouseholdExpenses,String transportation,
                                                                         String policiesAndInsurance,String clothing,String entertainment,
                                                                         String education,String savings, String phone, String creditCardPayments, String creditCardAmount)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveMonthlyExpenses(dashboardID,identityNumber,netSalary,loanOrRentAmount,utilities,foodAndHouseholdExpenses,
                transportation,policiesAndInsurance,clothing,entertainment,education,savings,phone,creditCardPayments,creditCardAmount);
        //DataDrive();
    }

    @Then("^the updating of monthly expense details result should return \"([^\"]*)\"$")
    public void the_updating_of_monthly_expense_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        createRecordTest.shouldGet200Response(result);
    }

    @When("^I submit monthly expense details to the system$")
    public void i_submit_monthly_expense_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions
        //test.callCSV("MonthlyExpensesData.csv");
        //test.getPosition(test.callCSV("MonthlyExpensesData.csv"), 1);
    }

    @Then("^the capturing of monthly expense details result should return \"([^\"]*)\"$")
    public void the_capturing_of_monthly_expense_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }

}
