package stepdefinitions;
import GlobalFunctions.ReadCSV;
import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;
import java.util.Properties;

public class BankingDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    List<String[]> lines;
    ReadCSV test;
    public BankingDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("BankingDetailsData.csv");
    }
    public void DataDrive()
    {
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            // createRecordTest.saveMonthlyExpenses(Integer.parseInt(lineContents[0]), identityNumber, netSalary, loanOrRentAmount, utilities, foodAndHouseholdExpenses,
            //        transportation, policiesAndInsurance, clothing, entertainment, education, savings, phone, creditCardPayments, creditCardAmount);
            createRecordTest.saveBankingDetails(Integer.parseInt(lineContents[0]), lineContents[1],
                    lineContents[2],
                    lineContents[3]);
        }
    }

    @When("^I submit banking details to the system$")
    public void i_submit_banking_details_to_the_system()  {
    }


    @Then("^the updating of banking details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successfully_added(String Result)  {
        createRecordTest.shouldGet200Response(Result);
    }
    @Then("^the capturing of banking details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successfully_updated(String Result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(Result);
    }

    @Given("^that I have a set of banking details \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_banking_details_and(int IDNumber, String BankName,String AccountNumber, String AccountType){
        // Write code here that turns the phrase above into concrete actions
       createRecordTest.saveBankingDetails(IDNumber,BankName,AccountNumber,AccountType);
        //DataDrive();
    }


    @Given("^that I have a set of changed bank details \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_bank_details_and(int IDNumber, String BankName,String AccountNumber, String AccountType)  {
        // Write code here that turns the phrase above into concrete actions
        //DataDrive();
        createRecordTest.saveBankingDetails(IDNumber,BankName,AccountNumber,AccountType);
    }
    @When("^when I validate that the banking details were updated I send \"([^\"]*)\"$")
        public void when_I_validate_that_the_banking_details_were_updated_I_send(String IDNumber)  {
            // Write code here that turns the phrase above into concrete actions
            getRecordTest.callGetRecordAPI(IDNumber, "bankingdetails");
        }

    @Then("^\"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\" must be correctly captured$")
    public void and_must_be_correctly_captured(int IdentityNumber , String BankName,String AccountNumber, String AccountType) {
        // Write code here that turns  throw new PendingException();
        //getRecordTest.validateBankingDetails(IdentityNumber,BankName,AccountNumber,AccountType);
    }
    @Then("^\"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\" must be correctly updated$")
    public void and_must_be_correctly_updated(int IdentityNumber , String BankName,String AccountNumber, String AccountType)  {
        // Write code here that turns the phrase above into concrete actions
        //getRecordTest.validateBankingDetails(IdentityNumber,BankName,AccountNumber,AccountType);
    }

}
