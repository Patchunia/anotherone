package stepdefinitions;

import GlobalFunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.DropdownAPITests;
import services.GetRecordAPITests;


import java.io.Console;
import java.net.URI;
import java.util.logging.ConsoleHandler;

public class DropdownAPIStep {

    DropdownAPITests dropdownTest;
    ReadCSV readCSV;
    public DropdownAPIStep()
    {
        dropdownTest  =  new DropdownAPITests();
        readCSV =  new ReadCSV();
    }
    @Given("^user sends \"([^\"]*)\" path$")
    public  void sendURI(String URI)
    {
        dropdownTest.sendRequest(URI);
    }


    @Then("^user views the dropdown data$")
    public void validateData() {

        dropdownTest.validateDropDown("Success");
    }
    @Given("^user sends dealer type details \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_sends_dealer_type_details_and(String dealerType, String dashboardID) {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.GetDealerType(dashboardID, dealerType);
    }
    @Given("^user sends vehicle make and model \"([^\"]*)\" , \"([^\"]*)\"  and \"([^\"]*)\"$")
    public void user_sends_vehicle_make_and_model_and(String make, String model, String vehicleType)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.sendVehicleMakeAndModel("getMMCodeMakes",make,model,vehicleType );
    }

    @Given("^user sends vehicle make by type \"([^\"]*)\" , \"([^\"]*)\"  and \"([^\"]*)\"$")
    public void user_sends_vehicle_make_by_type_and(String make, String model, String vehicleType)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.sendVehicleMakeAndModel("getMMCodeMakes",make,model,vehicleType );
    }

    @Then("^user views the correct  \"([^\"]*)\" dealer type details$")
    public void user_views_the_correct_dealer_type_details(boolean dealerTypeUpdate) {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.validateDealerType(dealerTypeUpdate);
    }



    @Given("^user sends location details \"([^\"]*)\"$")
    public void user_sends_location_details(String suburb)  {
        // Write code here that turns the phrase above into concrete actions
       dropdownTest.GetSurburb(suburb);
    }

    @Given("^user sends user sends dealersbyregion details \"([^\"]*)\"$")
    public void user_sends_user_sends_dealersbyregion_details(String city)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.Dealersbyregion(city);
    }

    @Then("^user views dealersbyregion$")
    public void user_views_dealersbyregion()  {
        // Write code here that turns the phrase above into concrete actions
            dropdownTest.validateDropDown("Success");
    }

    @Given("^user sends user sends citiesbyregions details \"([^\"]*)\"$")
    public void user_sends_user_sends_citiesbyregions_details(String city) {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.Citiesbyregions(city);
    }

    @Then("^user views citiesbyregions$")
    public void user_views_citiesbyregions()  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.validateDropDown("Success");
    }

    @Given("^user sends dealersbycity details  \"([^\"]*)\"$")
    public void user_sends_dealersbycity_details(String city)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.Dealersbycity(city);
    }

    @Then("^user views dealersbycity$")
    public void user_views_dealersbycity()  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.validateDropDown("Success");
    }


    @Then("^user views suburb \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_views_suburb_and(String postalCode, String city)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.ValidateSuburbResponse(postalCode,city);
    }
}
