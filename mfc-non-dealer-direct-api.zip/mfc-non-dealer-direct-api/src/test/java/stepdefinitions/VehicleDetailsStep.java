package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class VehicleDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public VehicleDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
    }
    @Given("^that I have a set of dealer vehicle details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_dealer_vehicle_details_and(int IDNumber, int vehicleYear,String vehicleMake, String mmCode,
                                                                boolean newVehicle,String dealer, String dealerCode, String VehicleModel, String VehicleType)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveVehicleDetails(IDNumber,vehicleYear,vehicleMake,mmCode,newVehicle,dealer,dealerCode,VehicleModel,VehicleType);
    }

    @Given("^that I have a set of changed dealer vehicle details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_dealer_vehicle_details_and(int IDNumber, int vehicleYear,String vehicleMake, String mmCode,
                                                                        boolean newVehicle,String dealer, String dealerCode, String VehicleModel, String VehicleType) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveVehicleDetails(IDNumber,vehicleYear,vehicleMake,mmCode,newVehicle,dealer,dealerCode,VehicleModel,VehicleType);
    }

    @Then("^the capturing of dealer vehicle details result should return \"([^\"]*)\"$")
    public void the_capturing_of_dealer_vehicle_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }

    @Then("^the updating of dealer vehicle details result should return \"([^\"]*)\"$")
    public void the_updating_of_dealer_vehicle_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        //createRecordTest.shouldGet200Response(result);
    }



    @When("^I submit dealer vehicle details to the system$")
    public void i_submit_dealer_vehicle_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions

    }


}
