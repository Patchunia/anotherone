package stepdefinitions;

import GlobalFunctions.Global;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class AcceptConsentStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global global_functions;
    public AcceptConsentStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        global_functions = new Global();
    }
    @Given("^that I have a set of qualifying criteria details \"([^\"]*)\" and presented with consent to \"([^\"]*)\",\"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_qualifying_criteria_details_and_presented_with_consent_to_and(int IDNumber, boolean creditEnquiryConsent,boolean shareBankStatmentsInformation,
                                                                                                   boolean payslipConsent, boolean tandcConsent ) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveQualifyingCriteria(IDNumber,creditEnquiryConsent,shareBankStatmentsInformation
        ,payslipConsent,tandcConsent);
    }

    @When("^I submit consent details to the system$")
    public void i_submit_consent_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of consent details result should return \"([^\"]*)\"$")
    public void the_capturing_of_consent_details_result_should_return(String result){
        // Write code here that turns the phrase above into concrete actions
       createRecordTest.shouldGet200Response(result);
    }

    @Given("^that I have a set of changed qualifying criteria details \"([^\"]*)\" and presented with consent to \"([^\"]*)\",\"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_qualifying_criteria_details_and_presented_with_consent_to_and(int IDNumber, boolean creditEnquiryConsent,boolean shareBankStatmentsInformation,
                                                                                                           boolean payslipConsent, boolean tandcConsent ) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveQualifyingCriteria(IDNumber,creditEnquiryConsent,shareBankStatmentsInformation,
                payslipConsent,tandcConsent);
    }

    @Then("^the updating of consent details result should return \"([^\"]*)\"$")
    public void the_updating_of_consent_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }



}
