package GlobalFunctions;


import au.com.bytecode.opencsv.CSVReader;
import com.beust.jcommander.ParameterException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class ReadCSV {
    private static final String csvFilePath = "src\\test\\resources\\testdata\\";
    private String[] line;
    private List<String[]> lines;
    public   List<String[]> callCSV(String fileName)
    {
        CSVReader reader;
        try {
            reader = new CSVReader(new FileReader(csvFilePath + fileName));

            lines = reader.readAll();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return  lines;
    }
    public void getPosition(List<String[]> lines, int position)
    {
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            System.out.println(lineContents[position]);
        }
    }

}
