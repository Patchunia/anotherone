package GlobalFunctions;

import net.serenitybdd.rest.SerenityRest;

import java.io.*;
import java.util.Properties;

public class Global {

    private Properties prop;
    private InputStream input ;
    public  String jwtToken = "";
    public  String endPoint = "";
    public  String applicationendPoint = "";
    public  String referenceDataendPoint = "";
    public  String approveITUrl = "";

    public  Global()
    {
        SerenityRest.proxy("172.17.2.12 ", 80);
        //SerenityRest.given().relaxedHTTPSValidation();
        prop = new Properties();
        try {
            input = new FileInputStream("target/classes/application.properties");
            prop.load(input);
            approveITUrl = prop.getProperty("approveITUrl");
            applicationendPoint = prop.getProperty("applicationUrl");
            referenceDataendPoint = prop.getProperty("referencedataUrl");
            jwtToken = prop.getProperty("jwt_token");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }





}


