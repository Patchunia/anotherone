package GlobalFunctions;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.junit.runner.RunWith;


public class DataDrivenTests {

}
