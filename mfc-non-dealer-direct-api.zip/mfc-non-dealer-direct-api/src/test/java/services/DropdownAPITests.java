package services;

import GlobalFunctions.Global;
import GlobalFunctions.ReadCSV;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;
import jdk.nashorn.internal.parser.JSONParser;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import java.awt.*;
import java.util.Iterator;
import static net.serenitybdd.rest.SerenityRest.enableLoggingOfRequestAndResponseIfValidationFails;
import static net.serenitybdd.rest.SerenityRest.proxy;
import static net.serenitybdd.rest.SerenityRest.useRelaxedHTTPSValidation;
import static org.hamcrest.Matchers.*;


public class DropdownAPITests extends Global {
    private Response response;
    private Response suburbResponse;
    private SerenityRest suburbRequest;
    private  ObjectTemplate vehicleObject;
    private JSONObject suburbObject;
    private  Global globalvariables;
    public ReadCSV readscv;
    public  DropdownAPITests()
    {
        vehicleObject = new ObjectTemplate();
        suburbRequest = new SerenityRest();
        suburbObject = new JSONObject();
        globalvariables = new Global();
        readscv = new ReadCSV();
    }
    @Step
    public Response sendPostRequest(String requestObject, String postUri){

        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .header("Authorization", "Bearer "+ globalvariables.jwtToken)
                .contentType("application/json")
                .body(requestObject)
                .when().post(globalvariables.referenceDataendPoint + postUri);
        return  response;
    }
    @Step
    public void sendRequest(String verifyuri){

        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .header("Authorization", "Bearer "+  globalvariables.jwtToken)
                .when().get(globalvariables.referenceDataendPoint  + verifyuri);

    }
    @Step
    public void validateDropDown(String result)
    {

       response.then().body("result.ResultMessage", equalTo(result));
    }
    @Step
    public void sendVehicleMakeAndModel(String URI, String Make, String Year, String VehType){
        response =  sendPostRequest(vehicleObject.VehicleMakeAndModelDetails(Make,Year,VehType).toString(), URI);
    }

    @Step
    public  void GetDealerType(String dashboardID, String dealerType)
    {
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .header("Authorization", "Bearer "+ globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .contentType("application/json")
                .when().post(globalvariables.applicationendPoint + "/dealertype/"+ dashboardID+ "/" + dealerType);
    }
    @Step
    public  void validateDealerType(boolean dealerTypeUpdate)
    {
        response.then().assertThat().body("dashboard.dealerType", equalTo(dealerTypeUpdate));
    }
    @Step
    public  void GetDealer(String dealerName)
    {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalvariables.jwtToken).
                body(vehicleObject.DealerObject(dealerName).toString()).contentType("application/json")
                .when().post(globalvariables.referenceDataendPoint + "dealerdetails");
    }
    @Step
    public  void ValidateDealerResponse(String dealerName, String dealerCode, String city, String suburb)
    {
        response.then().assertThat().body(
                "data.DealerCode[0]",
                equalTo(dealerCode));
    }
    @Step
    public  void Dealersbyregion(String Region)
    {
        sendPostRequest(vehicleObject.DealersbyregionDetails(Region).toString() , "dealersbyregion");
    }
    @Step
    public  void Citiesbyregions(String region)
    {

        sendPostRequest(vehicleObject.CitiesbyregionsDetails(region).toString() , "citiesbyregions");
    }
    @Step
    public  void Dealersbycity(String City)
    {

        sendPostRequest(vehicleObject.DealersbyCityDetails(City).toString() , "dealersbycity");
    }
    @Step
    public  void GetSurburb(String suburb)
    {

         suburbObject =  suburbObject.put("Suburbname", suburb);
         suburbResponse = suburbRequest.given().header("Authorization", "Bearer "+ globalvariables.jwtToken).
             body(suburbObject.toString()).contentType("application/json").when().post(globalvariables.referenceDataendPoint +"RetrieveSuburbs");
    }
    @Step
    public  void ValidateSuburbResponse(String postalCode, String city)
    {
        suburbResponse.then().assertThat().body("data[0].SuburbNames[0].city" , equalTo(city), "data[0].SuburbNames[0].postalCode", equalTo(postalCode));
        //suburbResponse.then().assertThat().body("ResultMessage", equalTo("Success"));
    }
    @Step
    public  void  shouldgetData()
    {
        response.then().assertThat().body("data", hasSize(greaterThan(0)));
    }

}