package services;

import gherkin.lexer.De;
import gherkin.lexer.Id;
import net.thucydides.core.annotations.Step;
import org.jruby.RubyProcess;
import org.jruby.ext.ripper.Warnings;
import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.Collection;


public class ObjectTemplate {

    private  JSONObject jsonDetailObj;
    private  JSONArray jsonArray;
    Object[] dashboards = new Object[0];
    @Step
    public JSONObject PersonalDetails(int IdentityNumber, String Title , String FirstName, String Surname ,
                                      String MaritalStatus, String WorkTelephone, String HomeTelephone,
                                      String EmailAddress,String AdditionalNationality, String Nationality
            , String Citizenship , String EthnicGroup, boolean MultipleNationality, boolean ForeignTaxObligation) {

        jsonDetailObj = new JSONObject()
                .put("action", "PersonalDetails")
                .put("applicationRefNo", IdentityNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails", new JSONObject()
                        .put("personalDetails", new JSONObject()
                                .put("dashboardId", 1)
                                .put("title", Title)
                                .put("firstName", FirstName)
                                .put("surName", Surname)
                                .put("maritalStatus", MaritalStatus)
                                .put("homePhone", HomeTelephone)
                                .put("workPhone", WorkTelephone)
                                .put("emailAddress", EmailAddress)
                                .put("birthCountry", Citizenship)
                                .put("nationality", Nationality)
                                .put("additionalNationality", AdditionalNationality)
                                .put("mulitpleNationality", MultipleNationality)
                                .put("ethnicGroup", EthnicGroup)
                                .put("foreignTaxObligation", ForeignTaxObligation)
                        ));
        return  jsonDetailObj;

    }


    public JSONObject MonthlyExpenses(int dashboardId, String identityNumber,int netSalary,String loanOrRentAmount,
                                      String utilities, String foodAndHouseholdExpenses,String transportation,
                                      String policiesAndInsurance,String clothing,String entertainment,
                                      String education,String savings, String phone, String creditCardPayments, String creditCardAmount,
                                      String accountPayments, String accountAmount, String loanPayments, String loanPaymentAmount,
                                      String otherPayments,String otherPaymentAmount, String totalExpenses , String remainingSurplus, String  maxMotorPayments,
                                             String  vehicleCashPrice) {

        jsonDetailObj = new JSONObject()
                         .put("action", "monthlyExpenses")
                         .put("applicationRefNo", dashboardId)
                         .put("dashboard",dashboards)
                        .put("monthlyExpenses", new JSONObject()
                                .put("dashboardId", dashboardId)
                                .put("identityNumber", identityNumber)
                                .put("netSalary", netSalary)
                                .put("loanOrRentAmount", loanOrRentAmount)
                                .put("utilities", utilities)
                                .put("foodAndHouseholdExpenses", foodAndHouseholdExpenses)
                                .put("transportation", transportation)
                                .put("policiesAndInsurance", policiesAndInsurance)
                                .put("clothing", clothing)
                                .put("entertainment", entertainment)
                                .put("education", education)
                                .put("savings", savings)
                                .put("phone", phone)
                                .put("creditCardPayments", creditCardPayments)
                                .put("creditCardAmount", creditCardAmount)
                                .put("accountPayments", accountPayments)
                                .put("accountAmount", accountAmount)
                                .put("loanPayments", loanPayments)
                                .put("loanPaymentAmount", loanPaymentAmount)
                                .put("otherPayments", otherPayments)
                                .put("otherPaymentAmount", otherPaymentAmount)
                                .put("totalExpenses", totalExpenses)
                                .put("remainingSurplus", remainingSurplus)
                                .put("maxMotorPayments", maxMotorPayments)
                                .put("vehicleCashPrice", vehicleCashPrice)
                        )
                        .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2));
        return  jsonDetailObj;

    }

    public JSONObject AddressDetails(int IdentityNumber, String PhysicalAddress,boolean MailAddressConfirmation ,String ResidentialStatus, String CurrentAddressDate,
                                     String PostalAddressLine1, String PostalAddressLine2,
                                     String Suburb, String City, String PostCode)
    {

        jsonDetailObj = new JSONObject()
                .put("action", "residentialAddress")
                .put("applicationRefNo", IdentityNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails", new JSONObject()
                        .put("residentialAddress", new JSONObject()
                                .put("dashboardId", 1)
                            .put("physicalAddress", PhysicalAddress)
                            .put("residentialStatus", ResidentialStatus)
                            .put("currentAddressDate", CurrentAddressDate)
                            .put("mailAddressConfirmation", MailAddressConfirmation)
                            .put("postalAddressFirst", PostalAddressLine1)
                            .put("PostalAddressLine2", PostalAddressLine2)
                            .put("Suburb", Suburb)
                            .put("City", City)
                            .put("PostCode", PostCode)));
        return jsonDetailObj;
    }

    public JSONObject ApproveITUSSD(String IDNumber, String CellPhoneNumber) {
        jsonDetailObj = new JSONObject()
                .put("Id", IDNumber)
                .put("Cell", CellPhoneNumber);

        return  jsonDetailObj;
    }

    public JSONObject EmploymentDetails(int IdentityNumber, String TypeOfEmployment, String Occupation, String CurrentEmployer,
                                        String Industry, String CurrentEmployerWorkingDate)
    {
        jsonDetailObj = new JSONObject()
                .put("action", "employmentDetails")
                .put("applicationRefNo", IdentityNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails", new JSONObject()
                        .put("employmentDetails", new JSONObject()
                .put("CurrentEmployer",CurrentEmployer)
                .put("currentEmployerWorkingDate",CurrentEmployerWorkingDate).put("dashboardId", IdentityNumber)
                .put("employmentType",TypeOfEmployment)
                .put("occupation",Occupation)
                .put("industryType",Industry)));
        return jsonDetailObj;
    }
    public JSONObject BankingDetails(int IDNumber, String BankName,String AccountNumber, String AccountType)
    {

        jsonDetailObj = new JSONObject()
                .put("action", "bankingDetails")
                .put("applicationRefNo", IDNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails", new JSONObject()
                        .put("bankingDetails", new JSONObject()
                                .put("dashboardId", IDNumber)
                                .put("accountNumber", AccountNumber)
                                .put("accountType",AccountType)
                                .put("bankName",BankName)
                                .put("branchCode",AccountNumber)));
        return  jsonDetailObj;
    }
    public JSONObject PersonalIncomeDetails(int IDNumber, int EarningBeforeDeduction,int EarningAfterDeduction,int MonthlyExpenses)
    {
        jsonDetailObj = new JSONObject()
                .put("action", "personalIncome")
                .put("applicationRefNo", IDNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails", new JSONObject()
                        .put("personalIncome", new JSONObject()
                                .put("dashboardId", IDNumber)
                                .put("earnBeforeDeductions",EarningBeforeDeduction)
                                .put("earnAfterDeductions",EarningAfterDeduction)
                                .put("monthlyExpenses",MonthlyExpenses)));
        return  jsonDetailObj;
    }
    public JSONObject VehicleMakeAndModelDetails(String Make, String Year, String VehType)
    {
        jsonDetailObj =  new JSONObject()
                .put("Make",Make)
                .put("CurrentYear",Year)
                .put("VehType",VehType);
        return  jsonDetailObj;
    }
    public JSONObject DealersbycityDetails(String City)
    {
        jsonDetailObj =  new JSONObject()
                .put("city",City);
        return  jsonDetailObj;

    }
    public JSONArray UploadDocDetails(String fileName,String appRef,String fileType, String fileFormat)
    {
        jsonDetailObj =
                new JSONObject( )
                .put("FileB64",fileName)
                .put("AppRef",appRef)
                .put("FileType",fileType)
                .put("FileFormat",fileFormat)
                        .put("id",1);
        jsonArray = new JSONArray().put(jsonDetailObj);

        return  jsonArray;
    }
    public JSONObject CitiesbyregionsDetails(String City)
    {
        jsonDetailObj =  new JSONObject()
                .put("Region",City);
        return  jsonDetailObj;

    }
    public JSONObject DealersbyCityDetails(String City)
    {
        jsonDetailObj =  new JSONObject()
                .put("City",City);
        return  jsonDetailObj;

    }
    public JSONObject DealersbyregionDetails(String region)
    {
        jsonDetailObj =  new JSONObject()
                .put("Region",region);
        return  jsonDetailObj;

    }
    public JSONObject SubmissionToFoxDetails(String dashboardId, String foxReference)
    {
        jsonDetailObj =  new JSONObject()
                .put("dashboardId",dashboardId)
                .put("foxReference",foxReference);
        return  jsonDetailObj;

    }
    public JSONObject SellerDetails(int IDNumber,String FirstName,String Surname,String CellPhone,String EmailAddress)
    {
        jsonDetailObj = new JSONObject()
                .put("action", "sellerDetails")
                .put("applicationRefNo", IDNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails", JSONObject.NULL)
                .put("vehicleFormDetails", new JSONObject()
                        .put("sellerDetails", new JSONObject()
                                        .put("firstName",FirstName)
                                        .put("surName",Surname)
                                        .put("dashboardId", IDNumber)
                                        .put("cellPhone",CellPhone)
                                        .put("emailAddress",EmailAddress))
                    );
        return  jsonDetailObj;
    }

    public JSONObject QualifyingCriteriaDetails(int IDNumber, boolean creditEnquiryConsent,boolean shareBankStatmentsInformation,
                                                boolean payslipConsent, boolean tandcConsent ) {
        jsonDetailObj = new JSONObject()
                .put("action", "qualifyingCriteria")
                .put("applicationRefNo", IDNumber)
                .put("dashboard",dashboards)
                        .put("qualifyingCriteria", new JSONObject()
                                .put("creditEnquiryConsent",creditEnquiryConsent)
                                .put("shareBankStatmentsInformation",shareBankStatmentsInformation)
                                .put("payslipConsent",payslipConsent)
                                .put("cellPhone","9999999999")
                                .put("identityNumber", IDNumber)
                                .put("tandcConsent",tandcConsent));

        return jsonDetailObj;
    }

    public JSONObject DealerObject(String dealerName) {
        jsonDetailObj =  new JSONObject()
                .put("Name", dealerName);
        return  jsonDetailObj;
    }

    public JSONObject VehicleDetails(int IDNumber, int vehicleYear, String vehicleMake, String mmCode,
                                     boolean newVehicle, String dealer, String dealerCode, String VehicleModel, String VehicleType)
    {

        jsonDetailObj = new JSONObject()
                .put("action", "vehicleDetails")
                .put("applicationRefNo",IDNumber )
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails",JSONObject.NULL)
                .put("vehicleFormDetails", new JSONObject()
                        .put("aboutYourVehicle", new JSONObject()
                        .put("identityNumber", IDNumber).put("dashboardId", IDNumber)
                        .put("vehicleYear",vehicleYear)
                        .put("vehicleMake",vehicleMake)
                        .put("mmCode",mmCode)
                        .put("newVehicle",newVehicle)
                        .put("dealer",dealer)
                        .put("dealerCode",dealerCode)
                        .put( "vehicleModel", VehicleModel)
                        .put( "vehicleType", VehicleType)
                        ));
        return  jsonDetailObj;

    }

    public JSONObject VehicleInstallmentDetails(int  IDNumber, String PurchasePrice,int Deposit,int BalloonPayment,
                                                boolean balloonPaymentOption,String firstPayment, int term,
                                                 int interestRate,int estimatedMonthlyInstalment, boolean dealerType)
    {

        jsonDetailObj = new JSONObject()
                .put("action", "vehicleInstalment")
                .put("applicationRefNo", IDNumber)
                .put("dashboard",dashboards)
                .put("navigationStep", new JSONObject()
                        .put("topNav", 1)
                        .put("sideNav", 2))
                .put("applicationFormDetails",JSONObject.NULL)
                .put("vehicleFormDetails", new JSONObject()
                        .put("vehicleInstalment" ,  new JSONObject()
                        .put( "purchasePrice", PurchasePrice).put("identityNumber", IDNumber).put("dashboardId", IDNumber)
                        .put( "deposit",  Deposit)
                        .put(  "balloonPayment",  BalloonPayment)
                        .put(  "balloonPaymentOption", balloonPaymentOption)
                        .put( "firstPayment",  firstPayment)
                        .put( "term",  term)
                        .put( "interestRate" ,  interestRate)
                        .put("estimatedMonthlyInstalment" ,  estimatedMonthlyInstalment)
                        .put(  "dealerType",  dealerType)));
        return  jsonDetailObj;
    }


}
