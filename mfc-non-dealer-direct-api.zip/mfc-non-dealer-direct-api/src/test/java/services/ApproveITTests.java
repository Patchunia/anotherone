package services;

import GlobalFunctions.Global;
import cucumber.api.java.en.Given;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;
import org.junit.Test;

import static org.hamcrest.Matchers.is;


public class ApproveITTests extends Global {
    private Response Initiateresponse;
    private Response Verifyresponse;
    private int verificationID;
    private  ObjectTemplate approveITObjects;
    private  Global globalvariables;
    private JSONObject jsonVerificationID;
    public  ApproveITTests()
    {
        globalvariables = new Global();
        approveITObjects =  new ObjectTemplate();
    }
    @Step
    public void sendRequest(String verifyuri, String IDNumber, String CellPhoneNumber){
        //SerenityRest.proxy("172.17.2.12 ", 80);
        Initiateresponse = SerenityRest.
                given().relaxedHTTPSValidation().body(approveITObjects.ApproveITUSSD(IDNumber, CellPhoneNumber).toString()).
                contentType("application/json").
                header("Authorization", "Bearer "+ globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .post(globalvariables.approveITUrl + verifyuri);
    }
    public  void validateInitiateResponse()
    {
        Initiateresponse.then()
                .body("result.ErrorState", is(false));
    }
    @Step
    public void sendVerificationID(String verifyuri, String OTP){
        Initiateresponse.then().statusCode(200).extract().path("data.VerificationID");
        //verificationID  = Initiateresponse.getBody().jsonPath().get("data.VerificationID");
        verificationID  = 342718;

            if(verifyuri  == "VerifyUSSDpoll") {
                jsonVerificationID = new JSONObject().put("VerificationID",verificationID);
            }
         else {
                jsonVerificationID = new JSONObject().put("VerificationID",verificationID).put("OTP" ,OTP);
            }
        Verifyresponse = SerenityRest
                .given().relaxedHTTPSValidation().
                body(jsonVerificationID.toString()).
                contentType("application/json")
                .header("Authorization", "Bearer "+ globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .post(globalvariables.approveITUrl  + verifyuri);

    }
    @Step
    public void shouldGetResponse(int result){
       // Verifyresponse.then().body("result.ErrorState", is(result));
        Verifyresponse.then().statusCode(result);
    }
}