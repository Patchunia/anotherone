package services;

import GlobalFunctions.Global;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.apache.tools.ant.taskdefs.Get;
import org.json.JSONObject;

import static org.hamcrest.Matchers.*;

public class GetRecordAPITests {
    private Response response;
    private  Global globalVariables;

    public GetRecordAPITests()
    {
        globalVariables = new Global();
    }

    public Response callGetAPI(String uri) {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalVariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .get( globalVariables.applicationendPoint + uri);
        return response;
    }

    @Step
    public  Response  callGetRecordAPI(String IdentityNumber, String action)
    {
        String uri  = "/" + IdentityNumber + "/" + action ;
         return  callGetAPI(uri);
    }
    @Step
    public  Response  callGetDashboardAPI(String IdentityNumber, String action)
    {
        String uri  = "/" + IdentityNumber + "/" + action ;
        return  callGetAPI(uri);
    }
    @Step
    public void validateBankingDetails(int IdentityNumber , String BankName,String AccountNumber, String AccountType)
    {
        response.then()
                .body("applicationFormDetails.bankingDetails.dashboardId", equalTo(IdentityNumber))
                .body("applicationFormDetails.bankingDetails.accountNumber", equalTo(AccountNumber))
                .body("applicationFormDetails.bankingDetails.accountType", equalTo(AccountType))
                .body("applicationFormDetails.bankingDetails.bankName", equalTo(BankName));
    }
    @Step
    public void validateEmploymentDetails(int IdentityNumber, String TypeOfEmployment,
                                          String Occupation, String CurrentEmployer,
                                          String Industry, String CurrentEmployerWorkingDate)
    {
        response.then()
                .body("applicationFormDetails.employmentDetails.dashboardId", equalTo(IdentityNumber))
                .body("applicationFormDetails.employmentDetails.employmentType", equalTo(TypeOfEmployment))
                .body("applicationFormDetails.employmentDetails.occupation", equalTo(Occupation))
                .body("applicationFormDetails.employmentDetails.industryType", equalTo(Industry))
                .body("applicationFormDetails.employmentDetails.currentEmployerWorkingDate", equalTo(CurrentEmployerWorkingDate))
                .body("applicationFormDetails.employmentDetails.currentEmployer", equalTo(CurrentEmployer));
    }

    @Step
    public  Response  callGetInstallmentAPI()
    {
        String uri = "/instalmentslookup";
        return  callGetAPI(uri);
    }
    @Step
    public void validateApplicationsIDNumber(String identityNumber)
    {
       response.then().body("result.ResultMessage", equalTo("Success"));
    }
}
