package services;
import GlobalFunctions.DataDrivenTests;
import GlobalFunctions.Global;
import ch.qos.logback.core.net.ssl.SSLConfiguration;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matcher;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.hamcrest.Matchers.*;
@RunWith(SerenityRunner.class)
public class CreateRecordAPITests {
    private Response response;
    private ObjectTemplate objectDetails;
    private Global globalvariables;
    public CreateRecordAPITests() {
        objectDetails = new ObjectTemplate();
        globalvariables = new Global();
    }

    @Step
    public void callCreateRecordAPI(JSONObject anyobject) {

        //SerenityRest.proxy("172.17.2.12 ", 80);
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.jwtToken )
                .header( "whoami" , "7109290834086")
                .when()
                .post(globalvariables.applicationendPoint );
    }

    @Step
    public void callUploadDoc(JSONArray anyobject) {
        //SerenityRest.proxy("https://servicesecuritygateway-dev.africa.nedcor.net" , 7804);
        SerenityRest.reset();
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .post("https://servicesecuritygateway-dev.africa.nedcor.net:7804/mfcapi/application/UploadDoc");
    }

    public void callSubmitToFoxAPI(JSONObject anyobject) {
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .post(globalvariables.applicationendPoint + "/SubmitToFox");
    }
    @Step
    public void saveSubmissionToFox(String dashboardId, String foxReference) {

       // callCreateRecordAPI(objectDetails.SubmissionToFoxDetails(dashboardId,foxReference));
        callSubmitToFoxAPI(objectDetails.SubmissionToFoxDetails(dashboardId,foxReference));
    }
    @Step
    public void saveBankingDetails(int IDNumber, String BankName, String AccountNumber, String AccountType) {

        callCreateRecordAPI(objectDetails.BankingDetails(IDNumber, BankName, AccountNumber, AccountType));
    }
    @Step
    public void saveDocuments(String fileName,String appRef,String fileType, String fileFormat) {

        callUploadDoc(objectDetails.UploadDocDetails(fileName,appRef,fileType,fileFormat));
    }

    @Step
    public void savePersonalIncome(int IDNumber, int EarningBeforeDeduction, int EarningAfterDeduction, int MonthlyExpenses) {

        callCreateRecordAPI(objectDetails.PersonalIncomeDetails(IDNumber, EarningBeforeDeduction, EarningAfterDeduction, MonthlyExpenses));

    }
    public void saveMonthlyExpenses(int dashboardID,String identityNumber,int netSalary,String loanOrRentAmount,
                                    String utilities, String foodAndHouseholdExpenses,String transportation,
                                    String policiesAndInsurance,String clothing,String entertainment,
                                    String education,String savings, String phone, String creditCardPayments, String creditCardAmount) {

       callCreateRecordAPI(objectDetails.MonthlyExpenses(dashboardID,identityNumber,netSalary,loanOrRentAmount, utilities,foodAndHouseholdExpenses,
               transportation,policiesAndInsurance,clothing,entertainment,education,savings,phone,creditCardPayments,creditCardAmount,"","",
               "","","","","","","",
               ""));

    }

    @Step
    public void saveFinanceAmount(int IDNumber, String PurchasePrice, int Deposit, int BalloonPayment,
                                  boolean balloonPaymentOption, String firstPayment, int term,
                                  int interestRate, int estimatedMonthlyInstalment, boolean dealerType) {

        callCreateRecordAPI(objectDetails.VehicleInstallmentDetails(IDNumber, PurchasePrice, Deposit, BalloonPayment,
                balloonPaymentOption, firstPayment, term, interestRate, estimatedMonthlyInstalment, dealerType));
    }

    @Step
    public void saveQualifyingCriteria(int IDNumber, boolean creditEnquiryConsent,boolean shareBankStatementsInformation,
                                       boolean payslipConsent, boolean tandcConsent )
    {
        callCreateRecordAPI(objectDetails.QualifyingCriteriaDetails(IDNumber,creditEnquiryConsent,shareBankStatementsInformation,
                payslipConsent, tandcConsent));
    }
    @Step
    public void saveSellerDetails(int IDNumber,String FirstName,String Surname, String CellPhone, String EmailAddress){

        callCreateRecordAPI(objectDetails.SellerDetails(IDNumber,FirstName,Surname,CellPhone,EmailAddress));
    }
    @Step
    public void saveVehicleDetails(int IDNumber, int vehicleYear,String vehicleMake, String mmCode,
                                   boolean newVehicle,String dealer, String dealerCode, String VehicleModel, String VehicleType){

        callCreateRecordAPI(objectDetails.VehicleDetails(IDNumber,vehicleYear,vehicleMake,mmCode,newVehicle,dealer,dealerCode,VehicleModel,VehicleType));
    }
    @Step
    public void savePersonalDetails(int IdentityNumber, String Title , String FirstName, String Surname ,
                                    String MaritalStatus, String WorkTelephone, String HomeTelephone,
                                    String EmailAddress,String AdditionalNationality, String Nationality
            , String Citizenship , String EthnicGroup, boolean MultipleNationality, boolean ForeignTaxObligation)
    {

        callCreateRecordAPI( objectDetails.PersonalDetails(IdentityNumber,Title,FirstName,Surname,
                MaritalStatus,WorkTelephone,HomeTelephone,EmailAddress,AdditionalNationality,Nationality,Citizenship,
                EthnicGroup,MultipleNationality,ForeignTaxObligation));

    }

    @Step
    public void saveResidentialAddress(int IdentityNumber, String PhysicalAddress,boolean MailAddressConfirmation ,String ResidentialStatus, String CurrentAddressDate,
                                       String PostalAddressLine1, String PostalAddressLine2,
                                       String Suburb, String City, String PostCode ){

        callCreateRecordAPI(objectDetails.AddressDetails(IdentityNumber,PhysicalAddress,MailAddressConfirmation,ResidentialStatus,CurrentAddressDate,
                PostalAddressLine1,PostalAddressLine2,Suburb,City,PostCode));

    }
    @Step
    public void saveEmploymentdetails(int IdentityNumber, String TypeOfEmployment, String Occupation, String CurrentEmployer,
                                      String Industry, String CurrentEmployerWorkingDate){

        callCreateRecordAPI( objectDetails.EmploymentDetails(IdentityNumber,TypeOfEmployment,Occupation,CurrentEmployer,Industry,CurrentEmployerWorkingDate));

    }
    @Step
    public  void saveInstallmentDetails(int  IDNumber, String PurchasePrice,int Deposit,int BalloonPayment,
                                        boolean balloonPaymentOption,String firstPayment, int term,
                                        int interestRate,int estimatedMonthlyInstalment, boolean dealerType)
    {
        callCreateRecordAPI( objectDetails.VehicleInstallmentDetails(IDNumber,
                PurchasePrice,Deposit,BalloonPayment,balloonPaymentOption, firstPayment,  term,
                 interestRate, estimatedMonthlyInstalment,  dealerType));
    }

    @Step
    public void shouldGet200Response(String value){

        response.then().body("result.ResultMessage" , equalTo(value));
    }
    @Step
    public void validateDocUpload(String result)
    {
        response.then().body("Response.Message" , equalTo(result));
    }
}
