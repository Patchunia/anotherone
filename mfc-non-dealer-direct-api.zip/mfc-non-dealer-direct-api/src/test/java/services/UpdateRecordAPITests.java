package services;

import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;

import static org.hamcrest.Matchers.equalToIgnoringWhiteSpace;
import static org.hamcrest.Matchers.is;

public class UpdateRecordAPITests {
    private String ISO_CODE_SEARCH = "http://NBPMFCP2PDEV01/mfcapi/application";
    private Response response;
    private int verificationID;
    private  ObjectTemplate objectDetails;
    private JSONObject jsonVerificationID;
    private String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5Mjc3MmFiMy0xZWMzLTRjMWQtOGE1Ny02YjhkZGZmZGVkZDAiLCJ0b2tlbl90eXBlIjoiQmVhcmVyIiwibmJmIjoxNTIzNDQzMjQ0LCJpc3MiOiJpZHAubmVkYmFuay5jby56YSIsImlhdCI6MTUyMzQ0MzMwNCwiZXhwIjoxNTU0OTc5MzA0LCJncmFudF90eXBlIjoiYW5vbnltb3VzIiwianRpIjoiMGRjODhjNzNmNWQ3NDNlMzg2MWM5NmFhMmVlOGM4ZmYiLCJzY29wZXMiOltdfQ.eWUwyfnYS1BvU7RmPYqpwhdD9DdxzeC9veOeOIu_IUzDCjL3VwLHTTLgKyzS0IYBcP8-KtoYMG1cZkyOYB2eVEccsV48pKG7KE51cYPeRfRTvdEsfnMir5RghlgA7k8N2izAjnpG6dwOeGyvKNffd-PMoIdskOsfGZgJGfR_30pq34y45RlUMur2bND-DpNBAv34V_KZKyYRo3WxWnvQXHq9UV7qWP6JFUoATMM2wrVmsUe_YDaTWE0DjnlmKao3Qo2f3yGOT4ujnV480ZkeCsdxh6d_RmWTll9aX7XOPLz3xT7EykqQ5CdxNjd7eEufDwnJqRbDMwqm_VWkhYbMYA";

    public  UpdateRecordAPITests()
    {
        objectDetails = new ObjectTemplate();
    }
    @Step
    public  void callUpdateRecordAPI(String uri , JSONObject anyobject)
    {
        response = SerenityRest
                .given()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer "+ token)
                .when()
                .put( ISO_CODE_SEARCH + uri);
    }

    @Step
    public void updateBankingDetails (String IDNumber, String BankName,String AccountNumber,String TypeOfAccount,String BranchCode ){
        //callUpdateRecordAPI("/banking",objectDetails.BankingDetails(IDNumber,AccountNumber,TypeOfAccount,TypeOfAccount, BranchCode));

    }

    @Step
    public void updatePersonalIncome(String IDNumber, String EarningBeforeDeduction,String EarningAfterDeduction,String MonthlyExpenses){

        //callUpdateRecordAPI("/banking",objectDetails.PersonalIncomeDetails(IDNumber,EarningBeforeDeduction,EarningAfterDeduction,MonthlyExpenses));

    }
    @Step
    public void updateFinanceAmount(String IDNumber, String Amount){


        //callUpdateRecordAPI("/loan",objectDetails.FinanceAmountDetails(IDNumber,Amount));
    }

    @Step
    public void updatePersonalDetails(String IDNumber, String Title , String FirstName, String Surname ,
                                    String MaritalStatus, String WorkTelephone, String HomeTelephone,
                                    String EmailAddress,String CellphoneNumber, String Nationality
                                             , String Citizenship , String EthnicGroup)
    {

        //callUpdateRecordAPI("/personal", objectDetails.PersonalDetails(IDNumber,Title,FirstName,Surname,MaritalStatus,WorkTelephone,HomeTelephone,EmailAddress,CellphoneNumber,Nationality,Citizenship,EthnicGroup));
    }

    @Step
    public void updateResidentialAddress(String IdentityNumber, String PhysicalAddress, String ResidentialStatus, String YearsOfStay,
                                       String PostalAddressLine1, String PostalAddressLine2,
                                       String Suburb, String City, String PostCode ){

        //callUpdateRecordAPI("/address", objectDetails.AddressDetails(IdentityNumber,PhysicalAddress,ResidentialStatus,YearsOfStay,PostalAddressLine1,PostalAddressLine2,Suburb,City,PostCode));

    }
    @Step
    public void updateEmploymentdetails(String IdentityNumber, String TypeOfEmployment, String Occupation, String CurrentEmployer,
                                      String Industry, String MonthsAtCurrentJob,
                                      String YearsAtCurrentJob){

        //callUpdateRecordAPI("/address", objectDetails.EmploymentDetails(IdentityNumber,TypeOfEmployment,Occupation,CurrentEmployer,Industry,MonthsAtCurrentJob,YearsAtCurrentJob));

    }

    @Step
    public void updateVehicleDetails(String IDNumber,String VNNumber, String DealerName,
                               String SellerName,String VehicleName, String VehicleMake, String VehicleModel,
                               String VehicleModelYear, String VehicleType, String IsVehicleNew){

        //callUpdateRecordAPI("/vehicle", objectDetails.VehicleDetails(IDNumber,VNNumber,DealerName,SellerName,VehicleName,VehicleMake,VehicleModel,VehicleModelYear,VehicleType,IsVehicleNew));

    }
    @Step
    public void shouldGetSuccessfulResponse(){
        response.then().body("MetaData.Message", is ("Successful"));
    }
}
